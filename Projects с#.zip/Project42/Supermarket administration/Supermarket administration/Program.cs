﻿using System;
using System.Collections.Generic;

namespace Supermarket_administration
{
    class Program
    {
        static void Main(string[] args)
        {
            Supermarket supermarket = new Supermarket();
            supermarket.LaunchSupermarket();
        }
    }

    class Supermarket
    {
        readonly private Queue _queue;
        readonly private Cashbox _cashbox;

        public Supermarket()
        {
            _queue = new Queue();
            _cashbox = new Cashbox();
        }

        public void LaunchSupermarket()
        {
            string command = "";

            _queue.AddInfoClients();
            _queue.AddInfoProducts();

            while (command != "exit")
            {
                Console.Write("\n Программа - Супермаркет.\n\n В данной программе В супермаркете есть очередь клиентов. У каждого клиента в корзине есть товары, также у клиентов\n есть деньги. Клиент, когда " +
                "подходит на кассу, получает итоговую сумму покупки и старается её оплатить. Если оплатить\n клиент не может, то он рандомный (любой товар попавшийся под руку) товар из корзины выкидывает до" +
                " тех пор, пока его\n денег не хватит для оплаты.\n\n Команды:\n show - программа показывает продукты и деньги клиентов,\n sale - покупка продуктов клиентом на кассе,\n exit - выход из" +
                " программы.\n");

                _queue.ShowAllInfoClients();
                //_queue.ShowInfoClients();

                Console.Write("\n Введите команду: ");
                command = Console.ReadLine();
                switch (command)
                {
                    case "show":
                        _queue.ShowAllInfoClients();
                        break;
                    case "sale":
                        _queue.GetFinalAmount(_cashbox);
                        break;
                }

                Console.Write("\n\n Нажмите любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Программа Магазин завершается.\n");
        }
    }

    class Queue
    {
        readonly private Client _client;
        private List<Product> _products;
        readonly private List<Money> _money;
        readonly private Dictionary<int, string> _clients;
        private int _counterClients = 0;

        public Queue()
        {
            _client = new Client();
            _money = new List<Money>();
            _products = new List<Product>();
            _clients = new Dictionary<int, string>();

            Money _money1 = new Money(400);
            Money _money2 = new Money(300);
            Money _money3 = new Money(200);
            Money _money4 = new Money(200);
            _money = new List<Money> { _money1, _money2, _money3, _money4 };
        }

        public void AddInfoClients()
        {
            _clients.Add(0, "Василий");
            _clients.Add(1, "Димов");
            _clients.Add(2, "Петров");
            _clients.Add(3, "Иванов");
        }

        public void AddInfoProducts()
        {
            _client.AddInfoProducts(ref _products);
        }

        public void OutputProductNumber(int i)
        {
            Console.Write(" Номер продукта - " + i);
        }

        public void ShowInfoProductsClient(int counterClients)
        {
            foreach (var client in _clients)
            {
                if (counterClients == client.Key)
                {
                    for (int i = 0; i < _products.Count; i++)
                    {
                        OutputProductNumber(i);
                        _products[i].ShowInfo();
                    }
                }
            }
        }

        public void ShowInfoMoney(int counterClients)
        {
            Console.Write(" Клиент - " + counterClients);

            foreach (var client in _clients)
            {
                if (counterClients == client.Key)
                {
                    _money[counterClients].ShowInfo();
                    Console.Write("\n");
                }
            }
        }

        public void ShowInfoClients()
        {
            Console.Write("\n Очередь клиентов:\n");
            foreach (var client in _clients)
            {
                Console.WriteLine(" " + client.Value);
            }
        }

        public void ShowAllInfoClients()
        {
            Console.WriteLine("\n");
            foreach (var client in _clients)
            {
                Console.WriteLine(" " + client.Value);
                ShowInfoProductsClient(_counterClients);

                if (_counterClients == client.Key)
                {
                    ShowInfoMoney(_counterClients);
                    _counterClients++;
                }
            }

            _counterClients = 0;
        }

        public void GetFinalAmount(Cashbox _cashbox) 
        {
            _cashbox.GetFinalAmount(_products, ref _counterClients, _clients, _money);
        }
    }

    class Client
    {
        public void AddInfoProducts(ref List<Product> _products)
        {
            Product _product1 = new Product("Йогурт", 200, "10.12.21 г.", 100);
            Product _product2 = new Product("Сыр", 100, "11.11.21 г.", 150);
            Product _product3 = new Product("Колбаса", 300, "05.06.21 г.", 200);
            Product _product4 = new Product("Сметана", 200, "07.06.21 г.", 200);

            _products = new List<Product> { _product1, _product2, _product3, _product4 };
        }
    }

    class Cashbox
    {
        private int _price;
        private int _randomProduct;
        readonly private Random _random;

        private bool Amount { get; set; }

        public Cashbox()
        {
            Amount = true;
            _random = new Random();
        }

        public void RandomRemoveProduct()
        {
            _randomProduct = _random.Next(0, 3);
        }

        public void Price(ref int _price)
        {
            _price = 0;
        }

        public void GetFinalAmount(List<Product> _products, ref int counterClients, Dictionary<int, string> _clients, List<Money> _money)
        {
            Price(ref _price);

            Console.Write("\n Общая сумма цены продуктов у клиента");
            for (int i = 0; i < _products.Count; i++)
            {
                Console.Write("\n " + _price + "\n");
                _price += _products[i].Price;
            }
            OutputFinalAmount(_products, _price, ref counterClients, _clients, _money);
        }

        public void OutputFinalAmount(List<Product> _products, int price, ref int counterClients, Dictionary<int, string> _clients, List<Money> _money)
        {
            if (Amount == true)
            {
                Console.WriteLine(" Итоговая сумма у " + counterClients + " клиента = " + price);
            }
            Amount = false;
            Sale(_products, _price, ref counterClients, _clients, _money);
        }

        public void Sale(List<Product> _products, int price, ref int counterClients, Dictionary<int, string> _clients, List<Money> _money)
        {
            foreach (var client in _clients)
            {
                if (counterClients == client.Key)
                {
                    while (_money[counterClients].Amount < price)
                    {
                        RandomRemoveProduct();
                        Console.Write("\n Удаление рандомного продукта.");
                        Console.Write("\n " + _randomProduct + "\n");
                        _products.RemoveAt(_randomProduct);
                        GetFinalAmount(_products, ref counterClients, _clients, _money);
                    }

                    Console.Write(" Клиент " + counterClients + " оплатил товары.\n\n");
                    _price = 0;
                    counterClients++;
                    Amount = true;
                }
            }
        }
    }

    class Money
    {
        public int Amount { get; private set; }

        public Money(int amount)
        {
            Amount = amount;
        }

        public void ShowInfo()
        {
            Console.WriteLine(", количество денег = " + Amount);
        }
    }

    class Product
    {
        private readonly string _name;
        private readonly int _weight;
        private readonly string _shelfLife;

        public int Price { get; private set; }

        public Product(string name, int weight, string shelfLife, int price)
        {
            _name = name;
            _weight = weight;
            _shelfLife = shelfLife;
            Price = price;
        }

        public void ShowInfo()
        {
            Console.WriteLine(", наименование продукта - " + _name + ", масса - " + _weight + " гр., срок годности " + _shelfLife + ", Цена - " + Price + ".");
        }
    }
}