﻿using System;

namespace largest_element
{
    class Program
    {
        static void Main(string[] args)
        {
            int largestElement = 1;
            int line;
            int column;
            int[,] matrix = {
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 11},
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 12},
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 13},
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 14},
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 15},
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 16},
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 17},
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 18},
                {1, 2, 3, 4, 5, 6, 7, 8, 9, 19}
            };

            Console.WriteLine("\n Программа нахождение наибольшего элемента матрицы\n Исходная матрица:");
            for (line = 0; line < matrix.GetLength(0); line++)
            {
                Console.Write(" ");
                for (column = 0; column < matrix.GetLength(1); column++)
                {
                    Console.Write(matrix[line, column] + " ");
                }
                Console.WriteLine();
            }

                for (line = 0; line < matrix.GetLength(0); line++)
            {
                for (column = 0; column < matrix.GetLength(1); column++)
                {
                    if (largestElement < matrix[line, column])
                    {
                        largestElement = matrix[line, column];
                    }
                }
            }

            for (line = 0; line < matrix.GetLength(0); line++)
            {
                for (column = 0; column < matrix.GetLength(1); column++)
                {
                    if (largestElement == matrix[line, column])
                    {
                        matrix[line, column] = 0;
                    }
                }
            }

            Console.WriteLine("\n Полученная матрица:");
            for (line = 0; line < matrix.GetLength(0); line++)
            {
                Console.Write(" ");
                for (column = 0; column < matrix.GetLength(1); column++)
                {
                    Console.Write(matrix[line, column] + " ");
                }
                Console.WriteLine();
            }

            Console.WriteLine("\n Наибольший элемент матрицы = " + largestElement);
            Console.WriteLine(" Программа нахождение наибольшего элемента матрицы завершается.\n");
        }
    }
}