﻿using System;

namespace КАНЗАС_СИТИ_ШАФЛ
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 4, 6, 7, 8, 9, 10, 25, 66};

            Console.Write("\n Программа - Перемешивание массива.\n Данная программа вывод иходный массив, затем вызывает функцию Shuffle, которая перемешивает элементы массива в\n случайном порядке, и в" +
            " основной фунции Main выводит полученный массив.\n\n Исходный массив:\n");
            OutArray(array);

            Shuffle(array);

            Console.Write("\n\n Полученный массив:\n");
            OutArray(array);

            Console.Write("\n\n");
        }

        static void OutArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(" " + array[i]);
            }
        }

        static void Shuffle(int[] array)
        {
            var random = new Random();
            int temp;
            int j;

            for (int i = array.Length - 1; i > 0; i--)
            {
                j = random.Next(i);
                temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }
}