﻿using System;

namespace Currency_Converter
{
    class Program
    {
        static void Main(string[] args)
        {
            string Input = "";
            string inputKonvert = "";
            int prizeEuro = 88;
            int prizeDollar = 74;
            float summKonvert;
            float Dollar = 200f;
            float Euro = 100f;
            float Rubles = 1000f;

            Console.Write(" Программа - конвертер валют.\n\n Цена Евро для 1 рубля = " + prizeEuro + ", Цена доллара для 1 рубля = " + prizeDollar + ".\n Введите команды dollar и rubles," +
            " если хотите сделать конвертацию рублей в доллары;\n Команду euro и rubles, если хотите сделать конвертацию рублей в Евро;\n Команду rubles и dollar, если хотите сделать" +
            " конвертацию с долларов в рубли;\n Команду rubles и euro, если хотите сделать конвертацию Евро в рубли.\n Или введите команду exit, если хотите завершить программу.\n\n");
            while (Input != "exit")
            {
                Console.Write(" Ваши деньги: баланс долларов = " + Dollar + ", баланс Евро = " + Euro + " и баланс рублей = " + Rubles + ".\n 1 команда: ");
                Input = Console.ReadLine();
                if (Input == "exit")
                {
                    break;
                }
                Console.Write(" 2 команда: ");
                inputKonvert = Console.ReadLine();

                if (Input == "dollar" && inputKonvert == "rubles")
                {
                    Console.Write(" Введите какую сумму рублей вы хотите перевести в доллары: ");
                    summKonvert = Convert.ToInt32(Console.ReadLine());
                    if (Rubles < summKonvert)
                    {
                        Console.Write(" Ваш баланс не позволяет сделать конвертацию валюты, попробуйте еще раз.");
                        break;
                    }
                    Dollar = Dollar + summKonvert / prizeDollar;
                    Rubles = Rubles - summKonvert;
                    Console.Write("\n");
                }
                else if (Input == "euro" && inputKonvert == "rubles")
                {
                    Console.Write(" Введите какую сумму рублей вы хотите перевести в eвро: ");
                    summKonvert = Convert.ToInt32(Console.ReadLine());
                    if (Rubles < summKonvert)
                    {
                        Console.Write(" Ваш баланс не позволяет сделать конвертацию валюты, попробуйте еще раз.");
                        break;
                    }
                    Euro = Euro + summKonvert / prizeEuro;
                    Rubles = Rubles - summKonvert;
                    Console.Write("\n");
                }
                else if (Input == "rubles" && inputKonvert == "euro")
                {
                    Console.Write(" Введите какую сумму eвро вы хотите перевести в рубли: ");
                    summKonvert = Convert.ToInt32(Console.ReadLine());
                    if (Euro < summKonvert)
                    {
                        Console.Write(" Ваш баланс не позволяет сделать конвертацию валюты, попробуйте еще раз.");
                        break;
                    }
                    Rubles = Rubles + summKonvert * prizeEuro;
                    Euro = Euro - summKonvert;
                    Console.Write("\n");
                }
                else if (Input == "rubles" && inputKonvert == "dollar")
                {
                    Console.Write(" Введите какую сумму долларов вы хотите перевести в рубли: ");
                    summKonvert = Convert.ToInt32(Console.ReadLine());
                    if (Dollar < summKonvert)
                    {
                        Console.Write(" Ваш баланс не позволяет сделать конвертацию валюты, попробуйте еще раз.");
                        break;
                    }
                    Rubles = Rubles + summKonvert * prizeDollar;
                    Dollar = Dollar - summKonvert;
                    Console.Write("\n");
                }
            }

            Console.WriteLine("\n Программа завершается!\n");
        }
    }
}