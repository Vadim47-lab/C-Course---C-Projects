﻿using System;
using System.IO;

namespace BRAVE_NEW_WORLD
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;

            bool isPlaying = true;
            int pacmanX, pacmanY;
            int pacmanDX = 0, pacmanDY = 1;
            int allDots = 0;
            int collectDots = 0;
            char[,] map = ReadMap("map1", out pacmanX, out pacmanY, ref allDots);

            DrowMap(map);
            Console.Write("   Карта игры Pac-man.\n\n");
            Console.WriteLine("\n\n Добро пожаловать в игру - Pac-Man. Данная программа берет готовую карту, которая состоит из подчеркиваний, игрока и\n границ из текстового файла и её отрисовыввет. Цель" +
            " игры: нужно собрать - " + allDots + " ягодок.\n\n Пояснение элементов игры: # - граница карты, _ - открытая зона, @ - управляемый игрок, . - ягодка.\n Управление персонажем происходит" +
            " стрелками на клавиатуре, кнопки: Esc - выход из игры, S - остановка игрока.\n");

            while (isPlaying)
            {
                Console.SetCursorPosition(0, 11);
                Console.WriteLine($" Собрано ягодок {collectDots}/{allDots}");

                if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);

                    ChangeDirection(key, ref pacmanDX, ref pacmanDY);
                    switch (key.Key)
                    {
                        case ConsoleKey.Escape:
                            Exit(ref isPlaying);
                            break;
                    }
                }

                if (map[pacmanX + pacmanDX, pacmanY + pacmanDY] != '#')
                {
                    Move(map, '@', ref pacmanX, ref pacmanY, pacmanDX, pacmanDY);
                    CollectDots(map, pacmanX, pacmanY, ref collectDots);
                }


                if (collectDots == allDots)
                {
                    Console.SetCursorPosition(0, 21);
                    Console.Write(" Молодец! Ты собрал все ягодки");
                    Exit(ref isPlaying);
                }

                System.Threading.Thread.Sleep(250);
            }
        }

        static void Exit(ref bool isPlaying)
        {
            isPlaying = false;
            Console.SetCursorPosition(0, 22);
            Console.Write(" Игра Pac-Man завершается.\n Нажмите на любую клавишу.\n");
        }

        static void ChangeDirection(ConsoleKeyInfo key, ref int DX, ref int DY)
        {
            switch (key.Key)
            {
                case ConsoleKey.UpArrow:
                    DX = -1;
                    DY = 0;
                    break;
                case ConsoleKey.DownArrow:
                    DX = 1;
                    DY = 0;
                    break;
                case ConsoleKey.LeftArrow:
                    DX = 0;
                    DY = -1;
                    break;
                case ConsoleKey.RightArrow:
                    DX = 0;
                    DY = 1;
                    break;
                case ConsoleKey.S:
                    DX = 0;
                    DY = 0;
                    break;
            }
        }

        static void Move(char[,] map, char symbol, ref int X, ref int Y, int DX, int DY)
        {
            Console.SetCursorPosition(Y, X);
            Console.Write(map[X, Y]);

            X += DX;
            Y += DY;

            Console.SetCursorPosition(Y, X);
            Console.Write(symbol);
        }

        static void CollectDots(char[,] map, int pacmanX, int pacmanY, ref int collectDots)
        {
            if (map[pacmanX, pacmanY] == '.')
            {
                collectDots++;
                map[pacmanX, pacmanY] = '_';
            }
        }

        static void DrowMap(char[,] map)
        {
            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                {
                    Console.Write(map[i, j]);
                }
                Console.WriteLine();
            }
        }

        static char[,] ReadMap(string mapName, out int pacmanX, out int pacmanY, ref int allDots)
        {
            pacmanX = 0;
            pacmanY = 0;

            string[] newFile = File.ReadAllLines($"Map/{mapName}.txt");
            char[,] map = new char[newFile.Length, newFile[0].Length];

            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                {
                    map[i, j] = newFile[i][j];

                    if (map[i, j] == '@')
                    {
                        pacmanX = i;
                        pacmanY = j;
                        map[i, j] = '.';
                    }
                    else if (map[i, j] == '$')
                    {
                        map[i, j] = '.';
                    }
                    else if (map[i, j] == '_')
                    {
                        map[i, j] = '.';
                        allDots++;
                    }
                }
            }

            return map;
        }
    }
}