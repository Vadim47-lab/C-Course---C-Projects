﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Объединение_коллекций_в_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            ActionsWithPlayers actionsWithPlayers = new ActionsWithPlayers();
            actionsWithPlayers.Start();
        }
    }

    class ActionsWithPlayers
    {
        public void Start()
        {
            List<Player> players = new List<Player> { new Player("ДжинОни", 100), new Player("ИзЦирка", 220), new Player("Дресслер", 250), new Player("Kekeksay", 241) };
            List<Player> newPlayers = new List<Player> { new Player("Jiro", 220), new Player("Keks", 260) };

            Console.Write(" Приложение - Выборка игроков на LINQ.\n Данная программа имеет 2 списка игроков, которых потом объединяют в единую коллекцию и затем она выводится в консоль.\n\n");

            Console.Write("\n Список игроков 1 коллекции:\n");
            foreach (var player in players)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            Console.Write("\n Список игроков 2 коллекции:\n");
            foreach (var player in newPlayers)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            var result = players.Union(newPlayers);

            Console.Write("\n Список игроков объединенной коллекции:\n");
            foreach (var player in result)
            {
                Console.Write(" " + player.Login + ".\n");
            }
        }
    }

    class Player
    {
        public string Login { get; private set; }
        public int Level { get; private set; }

        public Player(string login, int level)
        {
            Login = login;
            Level = level;
        }
    }
}