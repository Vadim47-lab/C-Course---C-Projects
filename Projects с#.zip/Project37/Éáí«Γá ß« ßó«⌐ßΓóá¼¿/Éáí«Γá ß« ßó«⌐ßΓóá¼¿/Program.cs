﻿using System;

namespace Работа_со_свойствами
{
    class Program
    {
        static void Main(string[] args)
        {
            Renderer renderer = new Renderer();
            Player player = new Player(2, 3);

            Console.Write("\n Программа - работа со свойствами.\n Данная программа отрисовывает игрока класса Player c с его свойствами через класс Renderer.\n");
            renderer.DrawPlayer(player.GetX(), player.GetY());
            Console.Write("\n\n Программа работа со свойствами завершается.\n");
        }
    }

    class Renderer
    {
        public void DrawPlayer(int x, int y, char player = '@')
        {
            Console.SetCursorPosition(x, y);
            Console.Write(player);
        }
    }

    class Player
    {
        private readonly int _x;
        private readonly int _y;

        public Player(int x, int y)
        {
            _x = x;
            _y = y;
        }

        public int GetX()
        {
            return _x;
        }

        public int GetY()
        {
            return _y;
        }
    }
}