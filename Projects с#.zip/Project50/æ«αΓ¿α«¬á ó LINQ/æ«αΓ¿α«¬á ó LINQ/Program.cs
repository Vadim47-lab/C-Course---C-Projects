﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Сортирока_в_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            ActionsWithPlayers actionsWithPlayers = new ActionsWithPlayers();
            actionsWithPlayers.Start();
        }
    }

    class ActionsWithPlayers
    {
        public void Start()
        {
            Console.Write(" Приложение - Выборка игроков на LINQ.\n Данная программа имеет список игроков, потом фильтруют с помощью сортировок убывания и возрастания, и затем выводятся" +
            "\n в консоль.\n\n");

            List<Player> players = new List<Player> { new Player("ДжинОни", 100), new Player("ИзЦирка", 220), new Player("Дресслер", 250), new Player("Kekeksay", 241) };

            Console.Write(" Список игроков:\n");
            foreach (var player in players)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            var filteredPlayers = players.Where(player => player.Level > 100).OrderBy(player => player.Level);

            Console.Write("\n Список отфильтрованных игроков по возрастанию:\n");
            foreach (var player in filteredPlayers)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            filteredPlayers = players.Where(player => player.Level > 100).OrderByDescending(player => player.Level);

            Console.Write("\n Список отфильтрованных игроков по убыванию:\n");
            foreach (var player in filteredPlayers)
            {
                Console.Write(" " + player.Login + ".\n");
            }
        }
    }

    class Player
    {
        public string Login { get; private set; }
        public int Level { get; private set; }

        public Player(string login, int level)
        {
            Login = login;
            Level = level;
        }
    }
}