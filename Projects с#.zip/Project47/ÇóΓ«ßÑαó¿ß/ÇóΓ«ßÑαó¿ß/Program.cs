﻿using System;
using System.Collections.Generic;

namespace Автосервис
{
    class Program
    {
        static void Main(string[] args)
        {
            CarService carService = new CarService();
            carService.StartWork();
        }
    }

    class CarService
    {
        private readonly Client _client;
        private readonly List<PartWarehouse> _partsWarehouse;
        private readonly int _priceWork = 100;
        private readonly int _penalty = 50;
        private int _money = 1000;
        private int _repairCost;

        public CarService()
        {
            _client = new Client();
            _partsWarehouse = new List<PartWarehouse>();
        }

        public void StartWork()
        {
            int maxAmountClients = 4;
            int countClient = 0;
            string command = "";

            AddParts();
            _client.AddСar();
            _client.AddPurse();

            while (command != "exit")
            {
                Console.Write("\n Приложение - Автосервис.\n В этом приложении есть автосервис, в который приезжают люди, чтобы починить свои автомобили. У автосервиса есть баланс  денег и" +
                " склад деталей. Когда приезжает автомобиль, у него сразу ясна его поломка, и эта поломка отображается в консоли  вместе с ценой за починку(цена за починку складывается из" +
                " цены детали + цена за работу). Поломка всегда чинится\n заменой детали, но количество деталей ограничено тем, что находится на складе деталей. Если у автосервиса нет\n " +
                "нужной детали на складе, то автосервис может отказать клиенту, и в этом случае автосервису придется выплатить штраф.\n Если автосервис заменит не ту деталь, то автосервису " +
                "придется возместить ущерб клиенту. За каждую удачную починку\n автосервис получает выплату за ремонт, которая указана в чек - листе починки.\n\n Команды:\n show - показать " +
                "детали со склада;\n repair - починка поломки автомобиля.\n\n");

                Console.Write(" Количество денег у автосервиса = " + _money + ".");

                Console.Write("\n\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "show":
                        ShowParts();
                        break;
                    case "repair":
                        if (countClient == maxAmountClients)
                        {
                            Console.Write("\n Список клинетов закончился. Можете сворачивать лавочку.");
                        }
                        else 
                        {
                            _client.ShowDescriptionCar( countClient);
                            RepairCost(countClient);
                            Repair(ref _money, countClient);
                            countClient++;
                        }
                        break;
                }

                Console.Write("\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Автосервис завершается.\n");
        }

        public void ShowParts()
        {
            Console.Write("\n Список деталей в складе:\n");
            for (int i = 0; i < _partsWarehouse.Count; i++)
            {
                Console.Write(" Номер - " + i);
                _partsWarehouse[i].ShowDescription();
            }
        }

        public void RepairCost(int countClient)
        {
            _repairCost = _partsWarehouse[countClient].Price + _priceWork;
            Console.Write(" Цена за починку = " + _repairCost + ".");
        }

        public void Repair(ref int money, int countClient)
        {
            int countRepair = countClient;

            ErrorAppearance(ref countRepair, countClient);

            if (_partsWarehouse[countClient].Amount == 0)
            {
                _money -= _penalty;
                Console.Write("\n Автосервис заплатил штраф.");
            }
            else if (_partsWarehouse[countRepair].Amount != _partsWarehouse[countClient].Amount)
            {
                _client.PaymentPenalty(ref money, countClient);
            }
            else
            {
                _client.RepairPayment(ref money, countClient);
            }
        }

        public void ErrorAppearance(ref int countRepair, int countClient)
        {
            int error = 2;

            if (countClient == error)
            {
                countRepair = 3;
            }
        }

        public void AddParts()
        {
            PartWarehouse part1 = new PartWarehouse("Дверь", 0, 100);
            PartWarehouse part2 = new PartWarehouse("Двигатель", 1, 200);
            PartWarehouse part3 = new PartWarehouse("Подвеска", 1, 150);
            PartWarehouse part4 = new PartWarehouse("Колесо", 0, 200);

            _partsWarehouse.Add(part1);
            _partsWarehouse.Add(part2);
            _partsWarehouse.Add(part3);
            _partsWarehouse.Add(part4);
        }
    }

    class Client
    {
        private readonly List<Purse> _wallets;
        private readonly List<Car> _cars;

        public Client()
        {
            _wallets = new List<Purse>();
            _cars = new List<Car>();
        }

        public void ShowDescriptionCar(int countClient)
        {
            Console.Write("\n Номер - " + countClient);
            _cars[countClient].ShowDescription();
        }

        public void PaymentPenalty(ref int money, int countClient)
        {
            money -= _wallets[countClient].Money;
            Console.Write("\n Автосервис возместил ущерб клиенту.");
        }

        public void RepairPayment(ref int money, int countClient)
        {
            money += _wallets[countClient].Money;
            Console.Write("\n Автосервис получил выплату за ремонт.");
        }

        public void AddPurse()
        {
            Purse purse1 = new Purse(400);
            Purse purse2 = new Purse(500);
            Purse purse3 = new Purse(600);
            Purse purse4 = new Purse(400);

            _wallets.Add(purse1);
            _wallets.Add(purse2);
            _wallets.Add(purse3);
            _wallets.Add(purse4);
        }

        public void AddСar()
        {
            Car car1 = new Car("Раф 4", "вмятина в двери");
            Car car2 = new Car("Лада", "сломался двигатель");
            Car car3 = new Car("Мицубиси", "износилась подвеска");
            Car car4 = new Car("Девятка", "спущено колесо");

            _cars.Add(car1);
            _cars.Add(car2);
            _cars.Add(car3);
            _cars.Add(car4);
        }
    }

    class Purse
    {
        public int Money { get; set; }

        public Purse(int money)
        {
            Money = money;
        }

        public void ShowDescription()
        {
            Console.WriteLine(", количество денег: " + Money + ".");
        }
    }

    class Car
    {
        private readonly string _name;
        private readonly string _breaking;

        public Car(string name, string breaking)
        {
            _name = name;
            _breaking = breaking;
        }

        public void ShowDescription()
        {
            Console.WriteLine(", название машины: " + _name + ", описание поломки: " + _breaking + ".");
        }
    }

    class PartWarehouse
    {
        private readonly string _name;

        public int Amount { get; private set; }

        public int Price { get; private set; }

        public PartWarehouse(string name, int amount, int price)
        {
            _name = name;
            Amount = amount;
            Price = price;
        }

        public void ShowDescription()
        {
            Console.WriteLine(", название: " + _name + ", количество деталей: " + Amount + ", цена детали: " + Price + ".");
        }
    }
}