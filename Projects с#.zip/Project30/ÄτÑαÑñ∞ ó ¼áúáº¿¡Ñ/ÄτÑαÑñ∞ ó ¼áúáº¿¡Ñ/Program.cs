﻿using System;
using System.Collections.Generic;

namespace Очередь_в_магазине
{
    class Program
    {
        static void Main(string[] args)
        {
            int bill = 0;
            Queue<int> сlients = new Queue<int>();
            сlients.Enqueue(10);
            сlients.Enqueue(20);
            сlients.Enqueue(34);
            сlients.Enqueue(55);
            сlients.Enqueue(25);

            while(сlients.Count != 0)
            {
                Console.WriteLine(" Программа - Очередь в магазине.\n Программа выводит все клиентов их обслуживает до тех пор, пока не закончится очередь. После каждого обслуженного\n клиента, деньги" +
                " добавляется на счет и выводятся.\n");

                Console.WriteLine(" Клиенты:");
                foreach (var client in сlients)
                {
                    Console.WriteLine(" " + client);
                }

                Console.WriteLine("\n Сейчас идет на прием - " + сlients.Peek());

                bill += сlients.Dequeue();
                Console.Write(" Cчет клиента = " + bill + ".");

                Console.Write("\n\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.WriteLine("Программа Очередь в магазине завершается. Нажмите на любую клавишу.");
        }
    }
}