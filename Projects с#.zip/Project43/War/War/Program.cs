﻿using System;
using System.Collections.Generic;

namespace War
{
    class Program
    {
        static void Main(string[] args)
        {
            Battle battle = new Battle();
            battle.StartBattle();
        }
    }

    class Battle
    {
        private readonly Squad _squad;
        private List<Fighter> _fighters;
        private List<Fighter> _fightersRussian;
        private List<Fighter> _fightersGerman;
        private Fighter _rightFigther;
        private Fighter _leftFigther;

        public Battle()
        {
            _squad = new Squad();
            _squad.AddInfoFighters(ref _fightersRussian, ref _fightersGerman);
        }

        public void StartBattle()
        {
            int fighterIndexRight = 0;
            int fighterIndexLeft = 1;
            int fighterIndex = 0;
            string command = "";

            while (command != "exit")
            {
                Console.Write("\n Приложение - Война.\n В этом приложении будет выведен результат битвы 2 зводов: Российский и Германский.\n Команды: fight - запуск битвы бойцов, exit - выход из приложения." +
                "\n Пояснение параметров: HP - жизнь, DMG - урон, Armor - броня.\n");

                _fighters = _fightersRussian;
                ShowStatsFighters(_fighters);

                _fighters = _fightersGerman;
                ShowStatsFighters(_fighters);

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                if (command == "fight")
                {
                    PreparingForBattle(ref _rightFigther, ref _leftFigther, fighterIndexRight, fighterIndexLeft, ref fighterIndex);

                    BattleFighters(_rightFigther, _leftFigther, fighterIndexLeft, fighterIndexLeft, ref fighterIndex);
                }

                Console.Write("\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение битвы завершается.\n");
        }

        public void ShowStatsFighters(List<Fighter> fighters)
        {
            for (int i = 0; i < _fighters.Count; i++)
            {
                Console.Write(" " + i + " ");
                _fighters[i].ShowStats();
                Console.Write("\n");
            }
        }

        public void PreparingForBattle(ref Fighter rightFigther, ref Fighter leftFigther, int fighterIndexRight, int fighterIndexLeft, ref int fighterIndex)
        {
            rightFigther = _fightersRussian[fighterIndexRight];
            Fighter figther = rightFigther;
            fighterIndex = fighterIndexRight;

            UsingAbilityFighter(fighterIndexRight, fighterIndex, figther);

            leftFigther = _fightersGerman[fighterIndexLeft];
            fighterIndex = fighterIndexLeft;

            ShowStatsFighters(ref fighterIndex);
        }

        public void ShowStatsFighters(ref int fighterIndex)
        {
            Console.Write(" Статы бойца после использования его способности:\n");
            _fightersRussian[fighterIndex].ShowStats();
            _fightersGerman[fighterIndex].ShowStats();
        }

        public void BattleFighters(Fighter rightFigther, Fighter leftFigther, int fighterIndexRight, int fighterIndexLeft, ref int fighterIndex)
        {
            int amountFighters = 4;
            int counterFighters = 0;

            Console.Write("\n\n Начало битвы:\n");
            while (counterFighters < amountFighters)
            {
                while (leftFigther.Health > 0 && rightFigther.Health > 0)
                {
                    Console.WriteLine();
                    leftFigther.TakeDamage(rightFigther.Damage);
                    rightFigther.TakeDamage(leftFigther.Damage);
                    leftFigther.ShowStats();
                    rightFigther.ShowStats();
                }

                counterFighters++;
                if (counterFighters == amountFighters)
                {
                    DeterminingWinner(rightFigther, leftFigther);
                    _squad.AddInfoFighters(ref _fightersRussian, ref _fightersGerman);
                    return;
                }

                RemoveFighter(rightFigther, fighterIndex);

                PreparingForBattle(ref rightFigther, ref leftFigther, fighterIndexRight, fighterIndexLeft, ref fighterIndex);
            }
        }

        public void DeterminingWinner(Fighter rightFigther, Fighter leftFigther)
        {
            if (rightFigther.Health <= 0)
            {
                Console.Write("\n Победили Российские бойцы");
            }
            else if (leftFigther.Health <= 0)
            {
                Console.Write("\n Победили Германские бойцы");
            }
            else if (leftFigther.Health <= 0 && leftFigther.Health <= 0)
            {
                Console.Write("\n Ничья.");
            }
        }

        public void UsingAbilityFighter(int fighterIndexRight, int fighterIndex, Fighter fighter)
        {
            if (fighterIndex == fighterIndexRight)
            {
                _fightersRussian[fighterIndex].UsingAbilityFighter(fighter);
            }
        }

        public void RemoveFighter (Fighter rightFigther, int fighterIndex)
        {
            if (rightFigther.Health <= 0)
            {
                _fightersRussian.RemoveAt(fighterIndex);
            }
        }
    }

    class Squad
    {
        public void AddInfoFighters(ref List<Fighter> _fightersRussian, ref List<Fighter> _fightersGerman)
        {
            John john = new John("John", 500, 50, 0);
            Mark mark = new Mark("Mark", 250, 20, 25);
            Alex alex = new Alex("Alex", 150, 100, 10);
            Max max = new Max("Max", 300, 30, 0);
            Kiborg kiborg = new Kiborg("Kiborg", 400, 50, 20);

            Alica alica = new Alica("Alica", 400, 40, 0);
            Peter peter = new Peter("Peter", 350, 30, 25);
            Vania vania = new Vania("Vania", 250, 80, 10);
            Vadim vadim = new Vadim("Vadim", 400, 40, 0);
            God god = new God("God", 300, 60, 20);

            _fightersRussian = new List<Fighter> { john, mark, alex, max, kiborg };
            _fightersGerman = new List<Fighter> { alica, peter, vania, vadim, god };
        }
    }

    abstract class Fighter
    {
        public string Name { get; set; }

        public int Armor { get; set; }

        public int Health { get; set; }

        public int Damage { get; set; }


        public Fighter(string name, int health, int damage, int armor)
        {
            Name = name;
            Health = health;
            Damage = damage;
            Armor = armor;
        }

        public void ShowStats()
        {
            Console.WriteLine(Name + ", HP: " + Health + ", DMG: " + Damage + ", Armor: " + Armor + ".");
        }

        public void DeterminingWinner()
        {
            Console.WriteLine(Name);
        }

        public void TakeDamage(int damage)
        {
            Health -= damage - Armor;
        }

        public abstract void UsingAbilityFighter(Fighter fighter);
    }

    class John : Fighter
    {
        public John(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Health -= 30;
            fighter.Damage += 20;
            Console.Write(" Способность (Крик) Джона активна.\n\n");
        }
    }

    class Mark : Fighter
    {
        public Mark(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Damage += 30;
            Console.Write(" Способность (Удушение) Марка активна.\n\n");
        }
    }

    class Alex : Fighter
    {
        public Alex(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Damage += 30;
            fighter.Armor -= 20;
            Console.Write(" Способность (Жало) Алекса активна.\n\n");
        }
    }

    class Max : Fighter
    {
        public Max(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Health -= 20;
            fighter.Damage += 40;
            fighter.Armor += 10;
            Console.Write(" Способность (Ярость) Макса активна.\n\n");
        }
    }

    class Kiborg : Fighter
    {
        public Kiborg(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Health += 10;
            fighter.Damage += 30;
            Console.Write(" Способность (Мясорубка) Киборга активна.\n\n");
        }
    }

    class Alica : Fighter
    {
        public Alica(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Health -= 30;
            fighter.Damage += 20;
            Console.Write(" Способность (Крик) Джона активна.\n\n");
        }
    }

    class Peter : Fighter
    {
        public Peter(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Damage += 30;
            Console.Write(" Способность (Удушение) Марка активна.\n\n");
        }
    }

    class Vania : Fighter
    {
        public Vania(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Damage += 30;
            fighter.Armor -= 20;
            Console.Write(" Способность (Жало) Алекса активна.\n\n");
        }
    }

    class Vadim : Fighter
    {
        public Vadim(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Health -= 20;
            fighter.Damage += 40;
            fighter.Armor += 10;
            Console.Write(" Способность (Ярость) Макса активна.\n\n");
        }
    }

    class God : Fighter
    {
        public God(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Health += 10;
            fighter.Damage += 30;
            Console.Write(" Способность (Мясорубка) Киборга активна.\n\n");
        }
    }
}