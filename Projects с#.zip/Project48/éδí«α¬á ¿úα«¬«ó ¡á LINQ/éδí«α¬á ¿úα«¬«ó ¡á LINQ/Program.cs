﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Выборка_игроков_на_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" Приложение - Выборка игроков на LINQ.\n Данная программа имеет список игроков, которых потом фильтруют по уровню больше 200 и выводят в консоль.\n\n");

            List<Player> players = new List<Player> { new Player("ДжинОни", 100), new Player("ИзЦирка", 220), new Player("Дресслер", 250), new Player("Kekeksay", 241) };

            Console.Write(" Список игроков:\n");
            foreach (var player in players)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            var filteredPlayers = from Player player in players
                                  where player.Level > 200
                                  select player.Login;

            Console.Write("\n Список отфильтрованных игроков:\n");
            foreach (var player in filteredPlayers)
            {
                Console.Write(" " + player + ".\n");
            }
        }
    }

    class Player
    {
        public string Login { get; private set; }
        public int Level { get; private set; }

        public Player(string login, int level)
        {
            Login = login;
            Level = level;
        }
    }
}