﻿using System;
using System.Collections.Generic;

namespace Динамический_массив_продвинутый
{
    class Program
    {
        static void Main(string[] args)
        {
            string command = "";
            List<int> numbers = new List<int>(0);

            while (command != "exit")
            {
                Console.Write("\n Добро пожаловать в приложение - динамический массив продвинутый.\n Имеются команды:\n sum (проиходит сложение всех введных чисел),\n add (дописать одно число в конец" +
                " списка),\n exit (выход из приложения).\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "add":
                        AddNumber(numbers);
                        break;

                    case "sum":
                        SumNumbers(numbers);
                        break;
                }

                Console.Write("\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение динамический массив продвинутый завершается.\n");
        }

        static void AddNumber(List<int> numbers)
        {
            Console.Write(" Введите число: ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                numbers.Add(number);
            }
            else
            {
                Console.WriteLine(" Введено не число. Попробуйте еще раз.");
                return;
            }

            OutNumbers(numbers);
        }

        static void OutNumbers(List<int> numbers)
        {
            Console.Write(" Созданный список чисел: ");
            for (int i = 0; i < numbers.Count; i++)
            {
                Console.Write(numbers[i] + " ");
            }
            Console.Write("\n");
        }

        static void SumNumbers(List<int> numbers)
        {
            int sum = 0;

            foreach(var number in numbers)
            {
                sum += number;
            }
            Console.Write(" Сумма всех введенных чисел = " + sum + "\n");
        }
    }
}