﻿using System;
using System.Collections.Generic;

namespace Компьютерный_клуб
{
    class Program
    {
        static void Main(string[] args)
        {
            ComputerClub computerClub = new ComputerClub(8);
            computerClub.Work();
        }
    }

    class ComputerClub
    {
        private int _money;
        private readonly List<Computer> _computers = new List<Computer>();
        private readonly Queue<Schoolboy> _schoolboys = new Queue<Schoolboy>();

        public void Work()
        {
            string command = "";

            while (_schoolboys.Count > 0 && command != "exit")
            {
                Schoolboy schoolboy = _schoolboys.Dequeue();

                Console.Write(" Приложение - Компьютерный клуб.");
                Console.Write("\n У компьютерного клуба есть компьютеры, на которых можно играть, заплатив определенную стоимость в минуту (смотреть\n ниже), которым хочет воспользоваться новый клиент, а" +
                " также есть некоторое количество денег, заработанные с клиентов.\n И у клиентов тоже есть деньги, которые они хотят потратить, играя за компьютером.\n");
                Console.Write(" Команды в приложении: start - запуск компьютерного клуба, exit - выход из приложения.\n\n");

                Console.Write($" У компьютерного клуба сейчас {_money} рублей, ждем нового клиента.");
                Console.Write($"\n В очереди молодой человек, он хочет купить {schoolboy.DesiredMinutes} минут.");
                Console.Write("\n\n Список компьютеров: \n");
                ShowComputers();

                Console.Write("\n Введите команду: ");
                command = Console.ReadLine();

                if (command == "start")
                {
                    Console.Write(" Введите новому клиенту компьютер по номером - ");
                    if (int.TryParse(Console.ReadLine(), out int computerNumber))
                    {
                        if (computerNumber >= 0 && computerNumber < _computers.Count)
                        {
                            if (_computers[computerNumber].IsBusy)
                            {
                                Console.Write(" Вы предложили клиенту компьютер, который уже занят. Клиент ушел.\n");
                            }
                            else
                            {
                                if (schoolboy.CheckSolvency(_computers[computerNumber]))
                                {
                                    Console.Write(" Пересчитав деньги клиент оплатил время и сел за компьютер.\n");
                                    _money += schoolboy.ToPay();

                                    _computers[computerNumber].TakeThePlace(schoolboy);
                                }
                                else
                                {
                                    Console.Write(" У клиента не хватило денег, он ушел.\n");
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.Write(" Вы сами не понимаете за какой компьютер клиента посадить. Клиент ушел.\n");
                    }

                    Console.Write("\n Для того чтобы перейти к новому клиенту нажмите на любую клавишу.");
                    SkipMinute();
                }

                if (command == "exit")
                {
                    Console.Write("\n Нажмите любую клавишу.");
                }
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Компьютерный клуб завершается.\n");
        }

        public void SkipMinute()
        {
            foreach (var computer in _computers)
            {
                computer.SkipMinute();
            }
        }

        private void ShowComputers()
        {
            for (int i = 0; i < _computers.Count; i++)
            {
                Console.Write($" {i} - ");
                _computers[i].ShowInfo();
            }
        }

        public ComputerClub(int ComputerCount)
        {
            Random rand = new Random();

            for (int i = 0; i < ComputerCount; i++)
            {
                _computers.Add(new Computer(rand.Next(5, 15)));
            }

            CreateNewSchoolBoy(25, rand);
        }

        private void CreateNewSchoolBoy(int Count, Random rand)
        {
            for (int i = 0; i < Count; i++)
            {
                _schoolboys.Enqueue(new Schoolboy(rand.Next(250, 300), rand));
            }
        }
    }

    class Computer
    {
        private Schoolboy _schoolboy;
        private int _minutesLeft;

        public int PriceForMinutes { get; private set; }

        public bool IsBusy
        {
            get
            {
                return _minutesLeft > 0;
            }
        }

        public Computer(int priceForMinutes)
        {
            PriceForMinutes = priceForMinutes;
        }

        public void TakeThePlace(Schoolboy schoolboy)
        {
            _schoolboy = schoolboy;
            _minutesLeft = _schoolboy.DesiredMinutes;
        }

        public void FreThePlace()
        {
            _schoolboy = null;
        }

        public void SkipMinute()
        {
            _minutesLeft--;
        }

        public void ShowInfo()
        {
            if (IsBusy)
            {
                Console.Write($"Компьютер занят. Осталось минут - {_minutesLeft}.\n");
            }
            else
            {
                Console.Write($"Компьютер свободен. Цена за минуту - {PriceForMinutes}.\n");
            }
        }
    }

    class Schoolboy
    {
        private int _money;
        private int _moneyToPay;

        public int DesiredMinutes { get; private set; }

        public Schoolboy(int money, Random rand)
        {
            _money = money;
            DesiredMinutes = rand.Next(10, 30);

        }

        public bool CheckSolvency(Computer computer)
        {
            _moneyToPay = computer.PriceForMinutes * DesiredMinutes;
            if (_money >= _moneyToPay)
            {
                return true;
            }
            else
            {
                _moneyToPay = 0;
                return false;
            }
        }

        public int ToPay()
        {
            _money -= _moneyToPay;
            return _moneyToPay;
        }
    }
}