﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Топ_игроков_сервера
{
    class Program
    {
        static void Main(string[] args)
        {
            Server server = new Server();
            server.StartWork();
        }
    }

    class Server
    {
        private readonly List<Player> _players;

        public Server()
        {
            _players = new List<Player>();
        }

        public void StartWork()
        {
            string command = "";

            AddPlayers();

            while (command != "exit")
            {
                Console.Write(" Приложение - Топ игроков сервера.\n В данной программе есть список всех игроков(минимум 10). У каждого игрока есть поля: имя, уровень, сила. Требуется\n " +
                "написать запрос для определения топ 3 игроков по уровню и топ 3 игроков по силе, после чего вывести каждый топ. 2\n запроса получится.\n\n Команды:\n 1) level - вывод топ 3 " +
                "игроков по уровню;\n 2) force -  вывод топ 3 игроков по силе;\n 4) exit - выход из программы.\n");

                ShowPlayers();

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "level":
                        SortingLevelPlayers();
                        break;
                    case "force":
                        SortingForcePlayers();
                        break;
                }

                Console.Write("\n\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Топ игроков сервера завершается.\n");
        }

        private void AddPlayers()
        {
            Player _player1 = new Player("Overlord", 100, 1000);
            Player _player2 = new Player("Kenshi", 50, 500);
            Player _player3 = new Player("Aukidzi", 80, 200);
            Player _player4 = new Player("Rimuru", 60, 2000);
            Player _player5 = new Player("God", 90, 1500);
            Player _player6 = new Player("Killer", 95, 800);
            Player _player7 = new Player("Dragon", 65, 700);
            Player _player8 = new Player("Djoker", 70, 300);
            Player _player9 = new Player("Superman", 75, 900);
            Player _player10 = new Player("Batman", 85, 1300);

            _players.Add(_player1);
            _players.Add(_player2);
            _players.Add(_player3);
            _players.Add(_player4);
            _players.Add(_player5);
            _players.Add(_player6);
            _players.Add(_player7);
            _players.Add(_player8);
            _players.Add(_player9);
            _players.Add(_player10);
        }

        private void ShowPlayers()
        {
            Console.Write("\n Список всех игроков:\n");
            for (int i = 0; i < _players.Count; i++)
            {
                Console.Write(" Номер - " + i);
                _players[i].ShowDescription();
            }
        }

        private void SortingLevelPlayers()
        {
            var sortingPlayersLevel = _players.OrderByDescending(player => player.Level).ToList();
            var resultLevelPlayer = sortingPlayersLevel.Take(3).ToList();

            ShowSortingLevelPlayers(resultLevelPlayer);
        }

        private void ShowSortingLevelPlayers(List<Player> resultLevelPlayer)
        {
            Console.Write("\n Вывод топ 3 игроков по уровню:\n");
            for (int i = 0; i < resultLevelPlayer.Count; i++)
            {
                Console.Write(" Номер - " + i);
                resultLevelPlayer[i].ShowDescription();
            }
        }

        private void SortingForcePlayers()
        {
            var sortingPlayersForce = _players.OrderByDescending(player => player.Force).ToList();
            var resultForcePlayer = sortingPlayersForce.Take(3).ToList();

            ShowSortingForcePlayers(resultForcePlayer);
        }

        private void ShowSortingForcePlayers(List<Player> resultForcePlayer)
        {
            Console.Write("\n Вывод топ 3 игроков по силе:\n");
            for (int i = 0; i < resultForcePlayer.Count; i++)
            {
                Console.Write(" Номер - " + i);
                resultForcePlayer[i].ShowDescription();
            }
        }
    }

    class Player
    {
        private readonly string _name;

        public int Level { get; private set; }
        public int Force { get; private set; }

        public Player(string name, int level, int force)
        {
            _name = name;
            Level = level;
            Force = force;
        }

        public void ShowDescription()
        {
            Console.Write(", имя - " + _name + ", уровень - " + Level + ", сила - " + Force + ".\n");
        }
    }
}