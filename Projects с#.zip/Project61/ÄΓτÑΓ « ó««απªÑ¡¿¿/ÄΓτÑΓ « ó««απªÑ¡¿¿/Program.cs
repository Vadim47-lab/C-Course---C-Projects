﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Отчет_о_вооружении
{
    class Program
    {
        static void Main(string[] args)
        {
            Detachment detachment = new Detachment();
            detachment.StartWork();
        }
    }

    class Detachment
    {
        private readonly List<Soldier> _soldiers;

        public Detachment()
        {
            _soldiers = new List<Soldier>();
        }

        public void StartWork()
        {
            string command = "";

            AddSoldiers();

            while (command != "exit")
            {
                Console.Write(" Приложение - Отчет о вооружении.\n В данной программе есть класс солдата. В нём есть поля: имя, вооружение, звание, срок службы(в месяцах). Написать запрос, " +
                "при помощи которого получить набор данных состоящий из имени и звания. Вывести все полученные данные в консоль. (Не менее 5 записей).\n\n Команды:\n 1) output - вывод набора" +
                " данных состоящего из имени и звания;\n 2) exit - выход из программы.\n");

                Console.Write("\n Список солдат:\n");
                ShowSoldiers();

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "output":
                        GetDataset();
                        break;
                }

                Console.Write("\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Отчет о вооружении завершается.\n");
        }

        private void AddSoldiers()
        {
            Soldier _soldier1 = new Soldier("Иван", "АК74", "Рядовой", 1);
            Soldier _soldier2 = new Soldier("Петров", "АК12", "Сержант", 2);
            Soldier _soldier3 = new Soldier("Сидоров", "винтовка снайперская ВСС", "Старший сержант", 4);
            Soldier _soldier4 = new Soldier("Саша", "снайперская винтовка Драгунова", "Старшина", 3);
            Soldier _soldier5 = new Soldier("Дима", "автомат специальный бесшумный", "Прапорщик", 6);

            _soldiers.Add(_soldier1);
            _soldiers.Add(_soldier2);
            _soldiers.Add(_soldier3);
            _soldiers.Add(_soldier4);
            _soldiers.Add(_soldier5);
        }

        private void ShowSoldiers()
        {
            for (int i = 0; i < _soldiers.Count; i++)
            {
                Console.Write(" Номер - " + i);

                _soldiers[i].ShowDescription();
            }
        }

        private void GetDataset()
        {
            int countSoldier = 0;

            var result = from Soldier soldier in _soldiers
                         select new
                         {
                             firstName = soldier.Name,
                             title = soldier.Rank
                         };

            Console.Write("\n Вывод набора данных состоящего из имени и звания:\n");
            foreach (var soldier in result)
            {
                Console.Write(" Номер - " + countSoldier + ", имя - " + soldier.firstName + ", звание - " + soldier.title + ".\n");
                countSoldier++;
            }
        }
    }

    class Soldier
    {
        private readonly string _armament;
        private readonly int _lifeTime;

        public string Name { get; private set; }
        public string Rank { get; private set; }

        public Soldier(string name, string armament, string rank, int lifeTime)
        {
            Name = name;
            _armament = armament;
            Rank = rank;
            _lifeTime = lifeTime;
        }

        public void ShowDescription()
        {
            Console.Write(", имя - " + Name + ", вооружение - " + _armament + ", звание - " + Rank + ", срок службы - " + _lifeTime + " месяц(ев).\n");
        }
    }
}