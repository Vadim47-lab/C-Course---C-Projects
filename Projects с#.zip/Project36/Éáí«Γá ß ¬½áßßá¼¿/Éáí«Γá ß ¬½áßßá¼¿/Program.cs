﻿using System;

namespace Работа_с_классами
{
    class Program
    {
        static void Main(string[] args)
        {
            Player[] player = {
                new Player(123424, "Петров Петр Петрович", "God Dragon", "Достичь желаемого результата - есть\n смысл жизни", 13), 
                new Player(14543438, "Сидоров Сидр Сидрович", "Watch Dog", "Двигаться вперед - значит жить", 17)
            };

            Console.Write("\n Программа - Работа с классами.\n В данной программе выводится информация о компьютерных игроках.\n\n Компьютерые игроки:\n");
            for (int i = 0; i < player.Length; i++)
            {
                Console.Write(" i - " + i + ",");
                player[i].ShowInfo();
            }

            Console.Write("\n Программа Работа с классами завершается.\n");
        }
    }

    class Player
    {
        private readonly int _id;
        private readonly string _fullName;
        private readonly string _nick;
        private readonly string _signature;
        private readonly int _timeSpentInGame;

        public Player (int id, string fullName, string nick, string signature, int timeSpentInGame)
        {
            _id = id;
            _fullName = fullName;
            _nick = nick;
            _signature = signature;
            _timeSpentInGame = timeSpentInGame;
        }

        public void ShowInfo()
        {
            Console.WriteLine(" Id - " + _id + ", ФИО - " + _fullName + ", Ник - " + _nick + ", Подпись - " + _signature + ",\n Количество времени проведенное в игре - " + _timeSpentInGame + " часов.\n");
        }
    }
}