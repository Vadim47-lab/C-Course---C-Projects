﻿using System;

namespace Score
{
    class Program
    {
        static void Main(string[] args)
        {
            int gold;
            int crystals;
            int price = 20;

            Console.Write("Введите начальное количество золота: ");
            gold = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите количество кристалов, которые вы хотите купить по цене " + price + ": ");
            crystals = Convert.ToInt32(Console.ReadLine());
            gold = gold - price * crystals;

            Console.WriteLine("\nОстаток золота = " + gold);
            Console.WriteLine("Количество полученых кристалов = " + crystals);
        }
    }
}