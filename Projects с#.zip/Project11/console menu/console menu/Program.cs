﻿using System;

namespace console_menu
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            string color;
            string name = "";
            string password = "";
            string output;
            string riddle;
            string exit = "";

            Console.Write(" Программа - консольное меню.\n\n В данном приложении есть команды, такие как (вводить команды на английском языке):\n color (изменить цвет консоли);\n name" +
            " (задать имя);\n password (задать пароль);\n output (вывести имя);\n exit (выход из программы);\n riddle (загадка).\n Все эти команды ты пользователь можешь использовать в " +
            "этом приложении.\n\n");

            while (exit != "exit")
            {
                Console.Write(" Введите команду: ");
                input = Console.ReadLine();
                
                switch(input)
                {
                    case "color":
                        Console.Write(" Введите в какой цвет вы хотите изменить консоль: blue (синий), green (зеленый), red (красный): ");
                        color = Console.ReadLine();
                        if (color == "blue")
                        {
                            Console.ForegroundColor = ConsoleColor.Blue;
                        }
                        else if (color == "green")
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                        }
                        else if (color == "red")
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                        }
                        Console.Write("\n");
                        break;

                    case "name":
                        Console.Write(" Введите ваше имя: ");
                        name = Console.ReadLine();
                        Console.Write("\n");
                        break;

                    case "password":
                        Console.Write(" Введите новый пароль: ");
                        password = Console.ReadLine();
                        Console.Write("\n");
                        break;

                    case "output":
                        Console.Write(" Введите пароль: ");
                        output = Console.ReadLine();
                        if (output == password)
                        {
                            Console.Write(" Имя пользователя - " + name + ".");
                        }
                        else
                        {
                            Console.Write(" Не правильный ввод пароля, попробуйте еще раз.");
                        }
                        break;

                    case "riddle":
                        Console.Write(" Загадка: к реке подходят два человека. У берега лодка, которая может выдержать только одного.\n Оба человека переправились на противоположный берег. Как?:\n " +
                        "Ответы: 1. Они были на одном берегу, 2. Они были на разных берегах.\n\n Введите ваш ответ ввиде: 1. или 2.: ");
                        riddle = Console.ReadLine();
                        if (riddle == "1.")
                        {
                            Console.Write(" Нет, ваш ответ не правильный, попробуйте еще раз.");
                        }
                        else if (riddle == "2.")
                        {
                            Console.Write(" Верно, ваш ответ правильный, вы молодцы.");
                        }
                        Console.Write("\n\n");
                        break;

                    case "exit":
                        exit = "exit";
                        break;
                }
            }

            Console.WriteLine("\n Программа консольное меню завершается!\n");
        }
    }
}