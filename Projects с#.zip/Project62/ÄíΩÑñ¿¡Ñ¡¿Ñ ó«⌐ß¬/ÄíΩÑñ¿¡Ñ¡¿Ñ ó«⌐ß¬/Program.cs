﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Объединение_войск
{
    class Program
    {
        static void Main(string[] args)
        {
            Army army = new Army();
            army.StartWork();
        }
    }

    class Army
    {
        private readonly List<Soldier> _squad1;
        private readonly List<Soldier> _squad2;

        public Army()
        {
            _squad1 = new List<Soldier>();
            _squad2 = new List<Soldier>();
        }

        public void StartWork()
        {
            string command = "";

            AddSquad1();
            AddSquad2();

            while (command != "exit")
            {
                Console.Write(" Приложение - Объединение войск.\n В данной программе есть 2 списка в солдатами. Всех бойцов из отряда 1, у которых фамилия начинается на букву Б,\n требуется" +
                " перевести в отряд 2.\n\n Команды:\n 1) output - вывод 2 отряда объединенного с 1 отрядом;\n 2) exit - выход из программы.\n");

                Console.Write("\n Список солдат 1 отряда:\n");
                ShowSquad(_squad1);

                Console.Write("\n Список солдат 2 отряда:\n");
                ShowSquad(_squad2);

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "output":
                        GetUnificationTroops();
                        break;
                }

                Console.Write("\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Отчет о вооружении завершается.\n");
        }

        private void AddSquad1()
        {
            Soldier _soldier1 = new Soldier("Баба Иван", "АК74", "Рядовой", 1);
            Soldier _soldier2 = new Soldier("Петров Петр", "АК12", "Сержант", 2);
            Soldier _soldier3 = new Soldier("Бабаж Сидр", "винтовка снайперская ВСС", "Старший сержант", 4);
            Soldier _soldier4 = new Soldier("Сидорович Саша", "снайперская винтовка Драгунова", "Старшина", 3);
            Soldier _soldier5 = new Soldier("Бабко Дима", "автомат специальный бесшумный", "Прапорщик", 6);

            _squad1.Add(_soldier1);
            _squad1.Add(_soldier2);
            _squad1.Add(_soldier3);
            _squad1.Add(_soldier4);
            _squad1.Add(_soldier5);
        }

        private void AddSquad2()
        {
            Soldier _soldier1 = new Soldier("Алеша Попович", "АК74", "Сержант", 1);
            Soldier _soldier2 = new Soldier("Добрыня Никитыч", "АК12", "Рядовой", 2);
            Soldier _soldier3 = new Soldier("Илья Муромец", "винтовка снайперская ВСС", "прапорщик", 4);
            Soldier _soldier4 = new Soldier("Никитович Игорь", "снайперская винтовка Драгунова", "Старший сержант", 3);
            Soldier _soldier5= new Soldier("Степанов Юра", "автомат специальный бесшумный", "Старшина", 6);

            _squad2.Add(_soldier1);
            _squad2.Add(_soldier2);
            _squad2.Add(_soldier3);
            _squad2.Add(_soldier4);
            _squad2.Add(_soldier5);
        }

        private void ShowSquad(List<Soldier> _squad)
        {
            for (int i = 0; i < _squad.Count; i++)
            {
                Console.Write(" Номер - " + i);

                _squad[i].ShowDescription();
            }
        }

        private void GetUnificationTroops()
        {
            int countSoldier = 0;

            var filteredSoldiersSquad1 = _squad1.Where(soldier => soldier.Name.ToUpper().StartsWith("Б"));

            var result = filteredSoldiersSquad1.Union(_squad2);

            Console.Write("\n Вывод 2 отряда объединенного с 1 отрядом:\n");
            foreach (var soldier in result)
            {
                Console.Write(" Номер - " + countSoldier + ", " + soldier.Name + "\n");
                countSoldier++;
            }
        }
    }

    class Soldier
    {
        private readonly string _armament;
        private readonly int _lifeTime;
        private readonly string _rank;

        public string Name { get; private set; }

        public Soldier(string name, string armament, string rank, int lifeTime)
        {
            Name = name;
            _armament = armament;
            _rank = rank;
            _lifeTime = lifeTime;
        }

        public void ShowDescription()
        {
            Console.Write(", имя - " + Name + ", вооружение - " + _armament + ", звание - " + _rank + ", срок службы - " + _lifeTime + " месяц.\n");
        }
    }
}