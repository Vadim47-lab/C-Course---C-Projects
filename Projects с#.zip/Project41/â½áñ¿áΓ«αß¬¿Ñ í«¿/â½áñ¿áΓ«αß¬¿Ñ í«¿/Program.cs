﻿using System;
using System.Collections.Generic;

namespace Battle
{
    class Program
    {
        static void Main(string[] args)
        {
            Battle battle = new Battle();
            battle.StartBattle();
        }
    }

    class Battle
    {
        private readonly List<Fighter> _fighters;

        public Battle()
        {
            John john = new John("John", 500, 50, 0);
            Mark mark = new Mark("Mark", 250, 20, 25);
            Alex alex = new Alex("Alex", 150, 100, 10);
            Max max = new Max("Max", 300, 30, 0);
            Kiborg kiborg = new Kiborg("Kiborg", 400, 50, 20);

            _fighters = new List<Fighter> { john, mark, alex, max, kiborg };
        }

        public void StartBattle()
        {
            int fighterIndexRight = 0;
            int fighterIndexLeft = 1;
            int fighterIndex = 0;
            string command = "";

            while (command != "exit")
            {
                Console.Write("\n Приложение - Битва.\n В этом приложении пользователю нужно будет выбрать бойцов для битвы и будет выведен результат их битвы.\n Команды: fight - запуск битвы бойцов," +
                " exit - выход из приложения.\n Пояснение параметров: HP - жизнь, DMG - урон, Armor - броня.\n\n");
                for (int i = 0; i < _fighters.Count; i++)
                {
                    Console.Write(" " + i + " ");
                    _fighters[i].ShowStats();
                }

                Console.Write("\n Введите команду: ");
                command = Console.ReadLine();

                if (command == "fight")
                {
                    ReceivingRightFighter(ref fighterIndex, ref fighterIndexRight);

                    Fighter rightFigther = _fighters[fighterIndexRight];
                    Fighter figther = rightFigther;

                    UsingAbilityFighter(ref fighterIndexRight, ref fighterIndexLeft, fighterIndex, figther);

                    ShowStatsFighters(ref fighterIndex);

                    ReceivingLeftFighter(ref fighterIndex,  ref fighterIndexLeft);

                    Fighter leftFigther = _fighters[fighterIndexLeft];
                    figther = rightFigther;

                    CheckingFighterSelection(ref fighterIndexRight, ref fighterIndexLeft);

                    UsingAbilityFighter(ref fighterIndexRight, ref fighterIndexLeft, fighterIndex, figther);

                    ShowStatsFighters(ref fighterIndex);

                    BattleFighters(rightFigther, leftFigther);

                    DeterminingWinner(rightFigther, leftFigther);

                    CheckingRemovalFighter(ref fighterIndexRight, ref fighterIndexLeft);

                    RemoveFighter(ref fighterIndexRight, ref fighterIndexLeft);

                    fighterIndex = 0;
                }

                Console.Write("\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение битвы завершается.\n");
        }

        public void CheckingFighterSelection(ref int fighterIndexRight, ref int fighterIndexLeft)
        {
            if (fighterIndexRight == fighterIndexLeft)
            {
                Console.WriteLine("\n Вы выбрали одиковых бойцов. Пожалуйста выберите разных бойцов.");
            }
        }

        public void ReceivingRightFighter(ref int fighterIndex, ref int fighterIndexRight)
        {
            Console.Write("\n Введите бойца правой стороны: ");
            if (int.TryParse(Console.ReadLine(), out fighterIndexRight))
            {
                Console.Write("\n Боец " + _fighters[fighterIndexRight].Name + " выбран.\n\n");
                fighterIndex = fighterIndexRight;
            }
            else
            {
                Console.Write("\n Вы ввели не бойца. Повторите попытку еще раз.");
            }
        }

        public void ReceivingLeftFighter(ref int fighterIndex, ref int fighterIndexLeft)
        {
            Console.Write(" Введите бойца левой стороны: ");
            if (int.TryParse(Console.ReadLine(), out fighterIndexLeft))
            {
                Console.Write("\n Боец " + _fighters[fighterIndexLeft].Name + " выбран.\n\n");
                fighterIndex = fighterIndexLeft;
            }
            else
            {
                Console.Write("\n Вы ввели не бойца. Повторите попытку еще раз.");
            }
        }

        public void ShowStatsFighters(ref int fighterIndex)
        {
            Console.Write(" Статы бойцов после использования их способностей:\n");
            _fighters[fighterIndex].ShowStats();
        }

        public void BattleFighters(Fighter rightFigther, Fighter leftFigther)
        {
            Console.Write("\n\n Начало битвы:\n");
            while (leftFigther.Health > 0 && rightFigther.Health > 0)
            {
                Console.WriteLine();
                leftFigther.TakeDamage(rightFigther.Damage);
                rightFigther.TakeDamage(leftFigther.Damage);
                leftFigther.ShowStats();
                rightFigther.ShowStats();
            }
        }

        public void DeterminingWinner(Fighter rightFigther, Fighter leftFigther)
        {
            if (rightFigther.Health <= 0)
            {
                Console.Write("\n Победил ");
                leftFigther.DeterminingWinner();
            }
            else if (leftFigther.Health <= 0)
            {
                Console.Write("\n Победил ");
                rightFigther.DeterminingWinner();
            }
            else if (leftFigther.Health <= 0 && leftFigther.Health <= 0)
            {
                Console.Write("\n Ничья.");
            }
        }

        public void UsingAbilityFighter(ref int fighterIndexRight, ref int fighterIndexLeft, int fighterIndex, Fighter fighter)
        {
            if (fighterIndex == fighterIndexRight)
            {
                _fighters[fighterIndex].UsingAbilityFighter(fighter);
            }
            else if (fighterIndex == fighterIndexLeft)
            {
                _fighters[fighterIndex].UsingAbilityFighter(fighter);
            }
        }

        public void RemoveFighter(ref int fighterIndexRight, ref int fighterIndexLeft)
        {
            for (int i = 0; i < _fighters.Count; i++)
            {
                if (fighterIndexRight == i)
                {
                    _fighters.RemoveAt(i);
                }
                if (fighterIndexLeft == i)
                {
                    _fighters.RemoveAt(i);
                }
            }
        }

        public void CheckingRemovalFighter(ref int fighterIndexRight, ref int fighterIndexLeft)
        {
            if (fighterIndexRight == fighterIndexLeft)
            {
                Console.WriteLine("\n Вы выбрали одиковых бойцов. Пожалуйста выберите разных бойцов.");
            }
        }
    }

    abstract class Fighter
    {
        public string Name { get; set; }

        public int Armor { get; set; }

        public int Health { get; set; }

        public int Damage { get; set; }


        public Fighter(string name, int health, int damage, int armor)
        {
            Name = name;
            Health = health;
            Damage = damage;
            Armor = armor;
        }

        public void ShowStats()
        {
            Console.WriteLine(Name + ", HP: " + Health + ", DMG: " + Damage + ", Armor: " + Armor + ".");
        }

        public void DeterminingWinner()
        {
            Console.WriteLine(Name);
        }

        public void TakeDamage(int damage)
        {
            Health -= damage - Armor;
        }

        public abstract void UsingAbilityFighter(Fighter fighter);
    }

    class John: Fighter
    {
        public John(string name, int health, int damage, int armor) : base(name, health, damage, armor) 
        {

        }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Health -= 30;
            fighter.Damage += 20;
            Console.Write(" Способность (Крик) Джона активна.\n\n");
        }
    }

    class Mark : Fighter
    {
        public Mark(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Damage += 30;
            Console.Write(" Способность (Удушение) Марка активна.\n\n");
        }
    }

    class Alex: Fighter
    {
        public Alex(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Damage += 30;
            fighter.Armor -= 20;
            Console.Write(" Способность (Жало) Алекса активна.\n\n");
        }
    }

    class Max: Fighter
    {
        public Max(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Health -= 20;
            fighter.Damage += 40;
            fighter.Armor += 10;
            Console.Write(" Способность (Ярость) Макса активна.\n\n");
        }
    }

    class Kiborg : Fighter
    {
        public Kiborg(string name, int health, int damage, int armor) : base(name, health, damage, armor) { }

        public override void UsingAbilityFighter(Fighter fighter)
        {
            fighter.Health += 10;
            fighter.Damage += 30;
            Console.Write(" Способность (Мясорубка) Киборга активна.\n\n");
        }
    }
}