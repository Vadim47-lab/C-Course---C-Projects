﻿using System;
using System.Collections.Generic;

namespace База_данных_игроков
{
    class User
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.StartDatabase();
        }
    }

    class Program
    {
        private readonly Database _database = new Database();
        public void StartDatabase()
        {
            string command = "";

            while (command != "exit")
            {
                Console.Write("\n Программа - База данных игроков.\n В данной программе выводится информация о компьютерных игроках: порядковый номер, ник, уровень игры и статус бана\n (true или false)." +
                " Если статус бана стал true => игрок забанен, а если false - игрок не забанен.\n Команды:\n exit - выход из приложения,\n add - добавление игрока,\n ban - бан игрока,\n unban - разбан" +
                " игрока,\n delete - удаление игрока.\n\n Компьютерые игроки:\n");

                _database.ShowPlayer();

                Console.Write("\n Введите команду: ");
                command = Console.ReadLine();
                switch (command)
                {
                    case "exit":
                        break;
                    case "add":
                        _database.Add();
                        break;
                    case "ban":
                        _database.Ban();
                        break;
                    case "unban":
                        _database.UnBan();
                        break;
                    case "delete":
                        _database.RemovePlayer();
                        break;
                }

                Console.Write("\n Нажмите любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Программа База данных игроков завершается.\n");
        }
    }

    class Database
    {
        private readonly static List<Player> _players = new List<Player>();
        private string _nick;
        private int _level;
        private bool _flagBan;

        public void Add()
        {
            string wordFlag;

            Console.Write(" Введите уровень игрока: ");
            if (int.TryParse(Console.ReadLine(), out _level))
            {
                Console.Write(" Введите ник игрока: ");
                _nick = Console.ReadLine();

                Console.Write(" Введите б - (бан) или н - (небан): ");
                wordFlag = Console.ReadLine();
                if (wordFlag == "б")
                {
                    _flagBan = true;
                }
                else
                {
                    _flagBan = false;
                }

                 Player _player2 = new Player(_nick, _level, _flagBan);
                _players.Add(_player2);
            }
            else
            {
                Console.Write(" Вы ввели не уровень. Попробуйте еще раз.");
            }
        }

        public void ShowPlayer()
        {
            for (int i = 0; i < _players.Count; i++)
            {
                Console.Write(" Порядковый номер - " + i);
                _players[i].ShowInfo();
            }
        }

        public void Ban()
        {
            Console.WriteLine(" Введите порядковый номер игрока: ");
            if (int.TryParse(Console.ReadLine(), out int serialNumber))
            {
                if (serialNumber < _players.Count)
                {
                    _players[serialNumber].Ban();
                }
                else
                {
                    Console.WriteLine(" Вы ввели порядковый номер игрока больше размера листа на данный момент. Попробуйте еще раз.");
                }
            }

            else
            {
                Console.WriteLine(" Вы ввели не число. Попробуйте еще раз.");
            }
        }

        public void UnBan()
        {
            Console.WriteLine(" Введите порядковый номер игрока: ");
            if (int.TryParse(Console.ReadLine(), out int serialNumber))
            {
                if (serialNumber < _players.Count)
                {
                    _players[serialNumber].UnBan();
                }
                else
                {
                    Console.WriteLine(" Вы ввели порядковый номер игрока больше размера листа на данный момент. Попробуйте еще раз.");
                }
            }

            else
            {
                Console.WriteLine(" Вы ввели не число. Попробуйте еще раз.");
            }
        }

        public void RemovePlayer()
        {
            Console.Write(" Введите порядковый номер игрока, которого вы хотите удалить: ");
            if (int.TryParse(Console.ReadLine(), out int delete))
            {
                if (delete > 0 && delete < _players.Count)
                {
                    _players.RemoveAt(delete);
                }
                else
                {
                    Console.WriteLine(" Вы ввели порядковый номер игрока больше размера листа на данный момент. Попробуйте еще раз.");
                }
            }

            else
            {
                Console.WriteLine(" Вы ввели не число. Попробуйте еще раз.");
            }
        }
    }

    class Player
    {
        private readonly string _nick;
        private readonly int _level;
        private bool _flagBan;

        public Player(string nick, int level, bool flagBan)
        {
            _nick = nick;
            _level = level;
            _flagBan = flagBan;
        }

        public void ShowInfo()
        {
            Console.WriteLine(", Ник - " + _nick + ", Уровень игры - " + _level + ", Статус бана - " + _flagBan + ".");
        }

        public void Ban()
        {
            _flagBan = true;
        }

        public void UnBan()
        {
            _flagBan = false;
        }
    }
}