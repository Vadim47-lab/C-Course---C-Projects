﻿using System;

namespace Pictures
{
    class Program
    {
        static void Main(string[] args)
        {
            int picturesCount = 52;
            int picturesInRow = 3;
            int fullyRow = 0;
            int picturesExcess = 0;

            fullyRow = picturesCount / picturesInRow;
            picturesExcess = picturesCount % picturesInRow;

            Console.WriteLine("Количество полностью заполненных рядов = " + fullyRow);
            Console.WriteLine("Количество картинок сверх меры = " + picturesExcess);
        }
    }
}
