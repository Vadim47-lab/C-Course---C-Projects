﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Из_IEnumerable_в_коллекцию_в_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            ActionsWithPlayers actionsWithPlayers = new ActionsWithPlayers();
            actionsWithPlayers.Start();
        }
    }

    class ActionsWithPlayers
    {
        public void Start()
        {
            List<Player> players = new List<Player> { new Player("ДжинОни", 100), new Player("ИзЦирка", 220), new Player("Дресслер", 250), new Player("Kekeksay", 241) };

            Console.Write(" Приложение - Выборка игроков на LINQ.\n Данная программа имеет список игроков, которых потом берут по условию, конверитруют в лист и затем выводится в\n консоль." +
            "\n\n");

            Console.Write("\n Список игроков коллекции:\n");
            foreach (var player in players)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            var result = players.TakeWhile(player => player.Login.StartsWith("Д"));
            result.ToList();

            Console.Write("\n Список игроков с взятием игрока, у которого имя начинается с буквы Д из коллекции:\n");
            foreach (var player in result)
            {
                Console.Write(" " + player.Login + ".\n");
            }
        }
    }

    class Player
    {
        public string Login { get; private set; }
        public int Level { get; private set; }

        public Player(string login, int level)
        {
            Login = login;
            Level = level;
        }
    }
}
