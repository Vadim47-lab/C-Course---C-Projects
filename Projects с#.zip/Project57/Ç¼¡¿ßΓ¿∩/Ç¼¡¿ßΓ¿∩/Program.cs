﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Амнистия
{
    class Program
    {
        static void Main(string[] args)
        {
            AmnestyInArstotsk amnestyInArstotsk = new AmnestyInArstotsk();
            amnestyInArstotsk.StartWork();
        }
    }

    class AmnestyInArstotsk
    {
        private readonly List<Criminal> _criminals;

        public AmnestyInArstotsk()
        {
            _criminals = new List<Criminal>();
        }

        public void StartWork()
        {
            string command = "";

            AddCriminals();

            while (command != "exit")
            {
                Console.Write(" Приложение - Амнистия.\n В данной программе в нашей великой стране Арстоцка произошла амнистия! Всех людей, заключенных за преступление\n (" +
                 "Антиправительственное), следует исключить из списка заключенных. Есть список заключенных, каждый заключенный имеет:\n ФИО, преступление. Будет осуществляться вывод списка" +
                 " заключенных до амнистии и после.\n\n Команды:\n show - показ списка преступников;\n free - освобождение преступников;\n exit - выход из программы.\n");

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "show":
                        ShowCriminals();
                        break;
                    case "free":
                        RemainingCriminals();
                        break;
                }

                Console.Write("\n\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Поиск преступника завершается.\n");
        }

        public void AddCriminals()
        {
            Criminal criminal1 = new Criminal("Петров Петр Петрович", "уголовное");
            Criminal criminal2 = new Criminal("Иван Иванов Иванович", "aнтиправительственное");
            Criminal criminal3 = new Criminal("Сидоров Сидр Сидорович", "aдминистративное");
            Criminal criminal4 = new Criminal("Александров Александр Александрович", "aнтиправительственное");

            _criminals.Add(criminal1);
            _criminals.Add(criminal2);
            _criminals.Add(criminal3);
            _criminals.Add(criminal4);
        }

        public void ShowCriminals()
        {
            Console.Write("\n Список преступников:\n");
            for (int i = 0; i < _criminals.Count; i++)
            {
                Console.Write(" Номер - " + i);
                _criminals[i].ShowDescription();
            }
        }

        public void RemainingCriminals()
        {
            string crime = "aнтиправительственное";

            var result = _criminals.Where(criminal => criminal.Сrime != crime).ToList();

            Console.Write("\n Список преступников после амнистии:\n");
            for (int i = 0; i < result.Count; i++)
            {
                Console.Write(" Номер - " + i);
                result[i].ShowDescription();
            }
        }
    }

    class Criminal
    {
        private readonly string _fullName;

        public string Сrime { get; private set; }

        public Criminal(string fullname, string сrime)
        {
            _fullName = fullname;
            Сrime = сrime;
        }

        public void ShowDescription()
        {
            Console.Write(", ФИО - " + _fullName + ", преступление - " + Сrime + ".\n");
        }
    }
}