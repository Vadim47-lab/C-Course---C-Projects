﻿using System;

namespace Exit_control
{
    class Program
    {
        static void Main(string[] args)
        {
            string Input = "";

            Console.WriteLine(" Программа - контроль выхода!\n");
            while (Input != "Exit")
            {
                Console.Write(" Введите любое слово, если хотите продолжить работу программы, или слово Exit, если хотите заврешить программу: ");
                Input = Console.ReadLine();
                if (Input != "Exit") 
                {
                    Console.Write(" Программа продолжает дальше работать!\n");
                }
                else if (Input == "Exit")
                {
                    Console.WriteLine(" Программа завершается!\n");
                }
            }
        }
    }
}