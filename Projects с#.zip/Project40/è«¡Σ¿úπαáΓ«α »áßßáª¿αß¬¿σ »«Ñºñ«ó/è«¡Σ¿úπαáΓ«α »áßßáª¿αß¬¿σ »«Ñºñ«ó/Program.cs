﻿using System;
using System.Collections.Generic;

namespace Конфигуратор_пассажирских_поездов
{
    class Programm
    {
        static void Main(string[] args)//Точка входа в программу Конфигуратор пассажирских поездов
        {
            TrainСonfigurator trainСonfigurator = new TrainСonfigurator();
            trainСonfigurator.Start();
        }
    }

    class TrainСonfigurator//программа Конфигуратор пассажирских поездов: имеет ссылки на классы направления, пассажиров, поездов и отправки поезда, выводит информацию о направлении, пассажиров
                           //поездов, имеет команды по созданию направления, пассажиров, поездов и отправки поезда.
    {
        readonly private Direction _direction;
        readonly private Passenger _passenger;
        readonly private Train _train;
        readonly private Send _send;

        public TrainСonfigurator()//Конструктор содержащий направления
        {
            _direction = new Direction();
            _passenger = new Passenger();
            _train = new Train();
            _send = new Send();
        }

        public void Start()//Метод запуск программы за счет команд по созданию направления, пассажиров, поездов и отправки поезда, а также  выводит информацию о направлении, пассажиров и поездов.
        {
            string command = "";
            bool createDirection = false;
            bool addPassengers = false;
            bool addCarriage = false;

            _direction.AddInfo();

            while (command != "exit")
            {
                Console.Write("\n Программа - Конфигуратор пассажирских поездов.\n Данная программа помогает пользователю составить план поезда.\n\n Команды:\n create (Создать направление) - выводит информацию" +
                " об городах и создаем направление для поезда (к примеру Бийск -\n Барнаул),\n sale (Продать билеты) - получаем рандомное кол-во пассажиров, которые купили билеты на это направление, а также " +
                "\n создаем поезд и добавляем ему столько вагонов (вагоны могут быть разные по вместительности), сколько хватит для\n перевозки всех пассажиров,\n send (Отправить поезд) - отправляем поезд, " +
                "после чего можем снова создать направление,\n exit - выход из программы.\n");

                if (createDirection == true)
                {
                    _direction.OutputDirection();
                }
                if (addPassengers == true)
                {
                    _passenger.ShowPassengers();
                }
                if (addCarriage == true)
                {
                    _train.ShowCarriage();
                }

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();
                switch (command)
                {
                    case "create":
                        _direction.ShowInfoDirection();
                        _direction.CreateDirection(ref createDirection);
                        break;
                    case "sale":
                        if (createDirection == true)
                        {
                            _passenger.AddPassengers(_train, ref addPassengers, ref addCarriage);
                            _train.ShowCarriage();
                        }
                        else
                        {
                            Console.Write("\n Направление еще не создано. Пожалуйста сформируйте направление.");
                        }
                        break;
                    case "send":
                        if (createDirection == true && addPassengers == true && addCarriage == true)
                        {
                            _direction.Send(_send);
                            _direction.Clear(ref createDirection);
                            _direction.AddInfo();
                            _passenger.Clear(ref addPassengers);
                            _train.Clear(ref addCarriage);
                        }
                        else
                        {
                            Console.Write("\n Поезд еще не сформирован. Пожалуйста сформируйте поезд.");
                        }
                        break;
                }

                Console.Write("\n\n Нажмите любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Программа Конфигуратор пассажирских поездов завершается.\n");
        }
    }

    class Direction//Класс по созданию направления движения поезда.
    {
        private int town1;
        private int town2;
        readonly private List<Town> _сities;

        public Direction()
        {
            _сities = new List<Town>();
        }

        public void AddInfo()//Метод добавления информации о направлении поезда.
        {
            Town _town1 = new Town("Томск");
            Town _town2 = new Town("Новосибирск");
            Town _town3 = new Town("Москва");
            Town _town4 = new Town("Санкт - Петербург");

            _сities.Add(_town1);
            _сities.Add(_town2);
            _сities.Add(_town3);
            _сities.Add(_town4);
        }

        public void ShowInfoDirection()//Метод показа информации направления поезда.
        {
            for (int i = 0; i < _сities.Count; i++)
            {
                Console.Write("\n Номер - " + i + ", название города - ");
                _сities[i].ShowInfo();
            }
        }

        public void CreateDirection(ref bool createDirection)//Метод создания направления поезда.
        {
            Console.Write("\n\n Введите первый номер города, от которого поедет поезд: ");
            if (int.TryParse(Console.ReadLine(), out town1))
            {
                Console.Write(" Введите второй номер города, к которому приедет поезд: ");
                if (int.TryParse(Console.ReadLine(), out town2))
                {
                    if (town1 < _сities.Count)
                    {
                        Console.Write("\n Создано направление: ");
                        _сities[town1].ShowInfo();
                    }
                    if (town2 < _сities.Count)
                    {
                         Console.Write(" - ");
                        _сities[town2].ShowInfo();
                        createDirection = true;
                    }
                }
                else
                {
                    Console.Write("\n Вы ввели не город. Попробуйте еще раз.");
                }
            }
            else
            {
                Console.Write("\n Вы ввели не город. Попробуйте еще раз.");
            }
        }

        public void OutputDirection()//Метод вывода направления поезда в консоль.
        {
            Console.Write("\n Текущий рейс: ");
            _сities[town1].ShowInfo();
            Console.Write(" - ");
            _сities[town2].ShowInfo();
        }

        public void Send(Send _send)//Метод передачи параметров для отправки поезда.
        {
            _send.SendTrain(_сities, town1,  town2);
        }

        public void Clear(ref bool createDirection)//Метод очистки информации о направлении и городах.
        {
            _сities.Clear();
            town1 = 0;
            town2 = 0;
            createDirection = false;
        }
    }

    class Town//Класс создания города
    {
        private readonly string _name;

        public Town(string name)
        {
            _name = name;
        }

        public void ShowInfo()//Метод показа информации о том или ином городе.
        {
            Console.Write(_name);
        }
    }

    class Passenger//Класс создания пассажиров.
    {
        private int passengers;
        readonly private Random rand;

        public Passenger()
        {
            rand = new Random();
        }

        public void RandomPassengers()//Метод создания рандомного количества пассажиров.
        {
            passengers = rand.Next(50, 100);
        }

        public void AddPassengers(Train _train, ref bool addPassengers, ref bool addCarriage)//Метод добавления пассажиров.
        {
            RandomPassengers();
            addPassengers = true;
            ShowPassengers();
            _train.FormTrain(ref passengers, ref addCarriage);
        }

        public void ShowPassengers()//Метод показа количества пассажиров.
        {
            Console.Write("\n Количество пассажиров = " + passengers);
        }

        public void Clear(ref bool addPassengers)//Метод очистки количества пассажиров.
        {
            passengers = 0;
            addPassengers = false;
        }
    }

    class Train//Класс создания поездов
    {
        private int _number;
        private int _capacity;
        readonly private List<Carriage> _carriages;

        public Train()
        {
            _carriages = new List<Carriage>();
        }

        public void ShowCarriage()//Метод показа поездов (количество, номер, вместимость).
        {
            for (int i = 0; i < _carriages.Count; i++)
            {
                _carriages[i].ShowInfo();
            }
        }

        public void FormTrain(ref int _passengers, ref bool addCarriage)//Метод создания поездов.
        {
            for (int i = 0; i < _passengers; i += _capacity)
            {
                Console.Write("\n Введите номер поезда: ");
                if (int.TryParse(Console.ReadLine(), out _number))
                {
                    Console.Write(" Введите вместимость поезда: ");
                    if (int.TryParse(Console.ReadLine(), out _capacity))
                    {
                        Carriage _carriage = new Carriage(_number, _capacity);
                        _carriages.Add(_carriage);
                    }
                    else
                    {
                        Console.Write("\n Вы ввели не вместимость поезда. Попробуйте еще раз.");
                    }
                }
                else
                {
                    Console.Write("\n Вы ввели не номер поезда. Попробуйте еще раз.");
                }
            }

            addCarriage = true;
        }

        public void Clear(ref bool addCarriage)//Метод очистки количества поездов, номеров поездов и вместимости поездов.
        {
            _carriages.Clear();
            _number = 0;
            _capacity = 0;
            addCarriage = false;
        }
    }

    class Carriage//Класс создания вагонов.
    {
        private readonly int _number;
        private readonly int _capacity;

        public Carriage(int number, int capacity)
        {
            _number = number;
            _capacity = capacity;
        }

        public void ShowInfo()//Метод показа информации о вагоне (номер, вместимость).
        {
            Console.Write("\n Номер вагона - " + _number + ", вместимость - " + _capacity + ".");
        }
    }

    class Send//Класс отправки поезда
    {
        public void SendTrain(List<Town> _сities, int town1, int town2)//Метод отправки поезда по такому-то направлению.
        {
            Console.Write("\n Поезд - ");
            _сities[town1].ShowInfo();
            Console.Write(" - ");
            _сities[town2].ShowInfo();
            Console.Write(" отправляется в путь.");
        }
    }
}