﻿using System;

namespace dynamic_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum;
            string command = "";
            int[] array = new int[0];

            Console.Write("\n Console.Write Добро пожаловать в приложение - динамический массив.\n Имеются команды: sum (проиходит сложение всех введных чисел),\n add (дописать одно число в конце массива),\n" +
            " exit (выход из приложения).\n");
            while (command != "exit")
            {
                int[] temp = new int[array.Length + 1];
                sum = 0;
                Console.Write("\n Введите команду: ");
                command = Console.ReadLine();

                if (command == "add")
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        temp[i] = array[i];
                    }

                    Console.Write(" Введите число: ");
                    temp[temp.Length - 1] = Convert.ToInt32(Console.ReadLine());

                    array = temp;

                    Console.Write("\n Созданный массив: ");
                    for (int i = 0; i < array.Length; i++)
                    {
                        Console.Write(array[i] + " ");
                    }
                }

                else if (command == "sum")
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        sum += array[i];
                    }
                    Console.Write("\n Сумма всех введенных чисел = " + sum);
                }
            }

            Console.Write("\n Приложение динамический массив завершается.\n");
        }
    }
}