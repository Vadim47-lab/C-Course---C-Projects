﻿using System;

namespace Password_program
{
    class Program
    {
        static void Main(string[] args)
        {
            int tryCount = 0;
            string password = "fish";
            string check;

            Console.Write(" Программа - программа под паролем.\n В программе имеется тайное сообщение, и чтобы его получить нужно ввести пароль. Количество попыток 3. Пароль тайного " +
            "сообщения - " + password + ".\n");

            while (tryCount < 3)
            {
                Console.Write("\n Введите пароль: ");
                check = Console.ReadLine();
                Console.Write("\n");

                if (check == password)
                {
                    Console.Write(" Тайное сообщение - тебя ждут только самые лучшие события в твоей жизни!\n");
                    break;
                }
                else if (check != password)
                {
                    Console.Write("\n Не верно введен пароль, попробуйте еще раз ввести пароль.");
                    tryCount = tryCount + 1;
                }
            }

            if (tryCount == 3)
            {
                Console.Write("\n Превышено количество попыток ввода пароля.");
            }
            Console.Write("\n\n Программа под паролем завершается.\n\n");
        }
    }
}