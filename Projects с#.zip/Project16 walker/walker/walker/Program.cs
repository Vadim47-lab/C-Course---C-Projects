﻿using System;

namespace walker
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            char[,] map =
            {
                {'#','#','#','#','#','#','#','#','#','#','#','#','#','#','#'},
                {'#',' ','#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
                {'#',' ','#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
                {'#','x','#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
                {'#',' ','#',' ',' ',' ',' ',' ','x',' ',' ',' ','x',' ','#'},
                {'#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
                {'#',' ','#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
                {'#',' ','#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
                {'#','x','#',' ',' ',' ',' ',' ','x',' ',' ',' ',' ',' ','#'},
                {'#',' ','#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
                {'#',' ','#',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','#'},
                {'#','#','#','#','#','#','#','#','#','#','#','#','#','#','#'},
            };
            int line, column;
            int userX = 6, userY = 6;
            int treasure = 0;
            int win = 5;
            int gameOver = 35;
            char[] bag = new char[0];
            char[] tempBag = new char[bag.Length + 1];
            float Steps = 0;//количество секунд

            while (true)
            {
                Steps = Steps + 1;
                Console.SetCursorPosition(0, 20);
                Console.Write(" Сумка: ");
                for (line = 0; line < bag.Length; line++)
                {
                    Console.Write(bag[line] + " ");
                }
                Console.Write("\n Количество собранных сокровищ = " + treasure);

                Console.SetCursorPosition(0,0);
                for (line = 0; line < map.GetLength(0); line++)
                {
                    for (column = 0; column < map.GetLength(1); column++)
                    {
                        Console.Write(map[line, column]);
                    }
                    Console.WriteLine();
                }
                Console.WriteLine("  Карта Бродилка.\n\n      Добро пожаловать в игру - Бродилка.\n В этой игре есть карта, на которой нужно будет собрать " + win + " сокровищ за " + 
                gameOver + " шагов.\n Пояснения: Ваш персонаж - @, сокровища - x, барьер - #, карта - Бродилка.\n количество шагов - " + Steps);

                Console.SetCursorPosition(userY, userX);
                Console.Write('@');
                ConsoleKeyInfo charKey = Console.ReadKey();

                switch (charKey.Key)
                {
                    case ConsoleKey.UpArrow:
                        if (map[userX - 1, userY] != '#')
                        {
                            userX--;
                        }
                        break;

                    case ConsoleKey.DownArrow:
                        if (map[userX + 1, userY] != '#')
                        {
                            userX++;
                        }
                        break;

                    case ConsoleKey.LeftArrow:
                        if (map[userX, userY - 1] != '#')
                        {
                            userY--;
                        }
                        break;

                    case ConsoleKey.RightArrow:
                        if (map[userX, userY + 1] != '#')
                        {
                            userY++;
                        }
                        break;
                }

                if (map[userX, userY] == 'x')
                {
                    map[userX, userY] = 'o';
                    treasure++;

                    for (line = 0; line < bag.Length; line++)
                    {
                        tempBag[line] = bag[line];
                    }
                    tempBag[tempBag.Length - 1] = 'x';
                    bag = tempBag;
                }

                if (treasure == win)
                {
                    Console.SetCursorPosition(0, 23);
                    Console.WriteLine(" Ты сумел собрать все сокровища = " + treasure + ". Молодец, так держать!\n");
                    break;
                }
                else if (Steps == gameOver)
                {
                    Console.SetCursorPosition(0, 25);
                    Console.WriteLine(" Ты проиграл и не успел собрать сокровища за " + Steps + " шагов - Game Over");
                    break;
                }

                Console.Clear();
            }

            Console.WriteLine(" Игра Бродилка завершается.\n");
        }
    }
}