﻿using System;

namespace Local_maxima
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int localMaxima = 1;
            int line;
            int[] array = new int[30];

            Console.Write(" Программа нахождение локальных максимумов в массиве.\n\n");
            for (line = 0; line < array.GetLength(0); line++)
            {
                array[line] = rand.Next(0, 30);
            }

            Console.Write(" Полученый массив = ");
            for (line = 0; line < array.GetLength(0); line++)
            {
                Console.Write(array[line] + " ");
            }

            Console.Write("\n Локальные максимумы = ");
            if (array[0] > array[1])
            {
                Console.Write(array[0] + " ");
            }

            for (line = 1; line < array.GetLength(0) - 1; line++)
            {
                if (array[line] > array[line - 1] && array[line] > array[line + 1])
                {
                    localMaxima = array[line];
                    Console.Write(localMaxima + " ");
                }
            }

            if (array[array.Length - 1] > array[array.Length - 2])
            {
                Console.Write(array[array.Length - 1] + " ");
            }

            Console.WriteLine("\n\n Программа нахождение локальных максимумов в массиве завершается.\n");
        }
    }
}