﻿using System;
using System.Linq;

namespace Personnel_accounting
{
    class Program
    {
        static void Main(string[] args)
        {
            string command = "";
            string findSurname = "";
            string[] fullName = new string[0];
            string[] post = new string[0];

            while (command != "e")
            {
                Console.Write("\n Добро пожаловать в приложение - кадровый учет.\n Имеются команды:\n a (add - добавить досье) - вводить ФИО через пробел,\n o (out - вывести все досье),\n d (delete - удалить" +
                " досье, полученное по поиску фамилии человека),\n s (search - поиск по фамилии),\n e (exit - выход из приложения).\n");
                Console.Write("\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "a":
                        AddDossier(ref fullName, ref post);
                        break;
                    case "o":
                        ShowDossier(fullName, post);
                        break;
                    case "d":
                        DeleteDossier(ref fullName, ref post);
                        break;
                    case "s":
                        SearchDossier(ref fullName, ref findSurname);
                        break;
                    case "e":
                        ExitАpplication();
                        break;
                }

                Console.Write(" Нажмите любую клавишу ");
                Console.ReadKey();
                Console.Clear();
            }
        }

        static void AddDossier(ref string[] fullName, ref string[] post)
        {
            string[] tempFullName = new string [fullName.Length + 1];
            string[] tempPost = new string[post.Length + 1];

            for (int i = 0; i < fullName.Length; i++)
            {
                tempFullName[i] = fullName[i];
                tempPost[i] = post[i];
            }

            Console.Write(" Введите ФИО человека: ");
            tempFullName[tempFullName.Length - 1] = Console.ReadLine();
            Console.Write(" Введите должность человека: ");
            tempPost[tempPost.Length - 1] = Console.ReadLine();

            fullName = tempFullName;
            post = tempPost;
        }

        static void ShowDossier(string[] fullName, string[] post)
        {
            Console.Write("  Вывод всех досье:");
            for (int i = 0; i < fullName.Length; i++)
            {
                Console.Write("\n " + i + " ФИО - " + fullName[i] + "  Должность - " + post[i]);
            }
            Console.Write("\n");
        }

        static void DeleteDossier(ref string[] fullName, ref string[] post)
        {
            int delete;
            string[] deleteFullName = new string[fullName.Length - 1];
            string[] deletePost = new string[post.Length - 1];

            Console.Write(" Введите порядковый номер человека, которого вы хотите удалить: ");
            delete = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < fullName.Length; i++)
            {
                if (i != delete)
                {
                    deleteFullName[i] = fullName[i];
                }
            }

            for (int i = 0; i < post.Length; i++)
            {
                if (i != delete)
                {
                    deletePost[i] = post[i];
                }
            }

            fullName = deleteFullName;
            post = deletePost;

            return;
        }

        static void SearchDossier(ref string[] fullName, ref string findSurname)
        {
            Console.Write(" Введите Фамилию человека: ");
            findSurname = Console.ReadLine();

            for (int i = 0; i < fullName.Length; i++)
            {
                bool find = fullName[i].Contains(findSurname);

                if (find)
                {
                    Console.Write(" Такой человек есть в базе с порядковым номером " + (i + 1) + ".\n");
                }
            }
        }

        static void ExitАpplication()
        {
            Console.Write(" Приложение кадровый учет завершается.\n Нажмите на любую клавишу.\n");
        }
    }
}