﻿using System;

namespace Sequence
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            int cycle = 98;
            int alternation = 7;
            int begin = 7;

            Console.Write(" Программа - последовательность.\n В данной программе выводится последовательность чисел определнным образом.\n\n Последовательность чисел - ");

            for (number = begin; number <= cycle; number += alternation)
            {
                Console.Write(number + " ");
            }
            Console.Write("\n\n Программа завершается.\n\n");
        }
    }
}