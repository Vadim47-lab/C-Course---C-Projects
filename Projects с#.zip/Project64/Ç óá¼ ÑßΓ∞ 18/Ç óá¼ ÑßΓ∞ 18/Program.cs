﻿using System;

namespace А_вам_есть_18
{
    class Program
    {
        static void Main(string[] args)
        {
            AgePerson agePerson = new AgePerson();
            agePerson.StartWork();
        }
    }

    class AgePerson
    {
        public void StartWork()
        {
            string command = "";

            while (command != "exit")
            {
                Console.Write(" Приложение - А вам есть 18?.\n Напиши на выбранном языке программу, которая запрашивает у пользователя возраст и отказывается работать, если\n пользователю " +
                "меньше 18.\n\n Команды:\n 1) age - проверка вашего возраста на 18 лет;\n 2) exit - выход из программы.\n");

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "age":
                        AgeCheck();
                        break;
                }

                Console.Write("\n\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение А вам есть 18? завершается.\n");
        }

        private void AgeCheck()
        {
            int permit = 18;

            Console.Write(" Введите ваш возраст: ");
            if (int.TryParse(Console.ReadLine(), out int age))
            {
                if (age < permit)
                {
                    Console.Write("\n Программа отказывается работать с вами, так как вам меньше " + permit + ".");
                }
                else
                {
                    Console.Write("\n Вас пустил охранник и вы вошли в бар!");
                }
            }
            else
            {
                Console.Write("\n Вы ввели не возраст. Повторите попытку еще раз.\n");
                AgeCheck();
            }
        }
    }
}