﻿using System;

namespace Polyclinic
{
    class Program
    {
        static void Main(string[] args)
        {
            int people;
            int minuteTime;
            int hourTime = 0;
            int time = 10;

            Console.Write("Введите количество людей: ");
            people = Convert.ToInt32(Console.ReadLine());
            minuteTime = people * time;
            if (minuteTime >= 60)
            {
                hourTime = minuteTime / 60;
                minuteTime = minuteTime % 60;
            }

            Console.WriteLine("Вы должны отстоять в очереди = " + hourTime + " часа(ов) и " + minuteTime + " минут");
        }
    }
}
