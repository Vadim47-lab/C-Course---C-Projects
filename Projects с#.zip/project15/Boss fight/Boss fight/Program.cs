﻿using System;

namespace Boss_fight
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int healthHero = rand.Next(250, 260);
            int healthBoss = rand.Next(500, 600);
            int deathSubject = 0;
            int damageBoss = rand.Next(100, 110);
            string input;
            string rashamon = "rashamon";
            int rashamonDamage = 100;
            bool huganzakuraOpen = false;
            string huganzakura = "huganzakura";
            int huganzakuraDamage = 100;
            string rift = "rift";
            int maxHealth = 300;
            int recovery = 250;
            string ulta = "ulta";
            int ultaDamage = 200;
            int selfDamage = 50;

            Console.Write("\n Игра - битва с боссом.\n Легенда: Вы – теневой маг и у вас в арсенале есть несколько заклинаний, которые вы можете использовать против Босса.\n Вы должны" +
            " уничтожить босса и только после этого будет вам покой.\n\n хп - здоровье. У вас есть 4 заклинания для нанесения урона боссу:\n 1. rashamon - призывает теневого духа " +
            "(Отнимает " + rashamonDamage + " хп боссу);\n 2. huganzakura - Может быть выполнен только после призыва теневого духа (наносит " + huganzakuraDamage + " ед. урона);\n 3. rift" +
            " – позволяет скрыться в разломе и восстановить " + recovery + " хп. Урон босса по вам не проходит;\n 4. ulta - наносит большой урон = " + ultaDamage + ", но уменьшает хп на " +
            selfDamage + ".\n Урон босса = " + damageBoss + ", Максимальное здоровье игрока = " + maxHealth + ".\n Игра завершится только после смерти босса или смерти  пользователя.\n\n");

            while (healthHero > deathSubject || healthBoss > deathSubject)
            {
                Console.Write("\n Ваше хп = " + healthHero + ", хп босса = " + healthBoss + ".");
                if (healthHero <= deathSubject)
                {
                    Console.Write("\n\n Вас убил босс  - Game Over!");
                    break;
                }
                else if (healthBoss <= deathSubject)
                {
                    Console.Write("\n\n Вы убили босса, молодец  - Win!");
                    break;
                }

                Console.Write("\n Введите заклинание: ");
                input = Console.ReadLine();

                if (input == rashamon)
                {
                    healthBoss = healthBoss - rashamonDamage;
                    Console.Write("\n Заклинание расшамон ранило босса, урон = " + rashamonDamage + ".\n");
                    huganzakuraOpen = true;
                }
                else if (input == huganzakura && huganzakuraOpen == true)
                {
                    healthBoss = healthBoss - huganzakuraDamage;
                    Console.Write("\n Заклинание хуганзакура нанесло урон боссу = " + huganzakuraDamage + ".\n");
                }
                else if (input == huganzakura && huganzakuraOpen == false)
                {
                    Console.Write("\n Не было введено заклинание - " + rashamon + ".\n Попробуйте ввести новое заклинание.");
                }
                else if (input == rift)
                {
                    healthHero = healthHero + recovery;
                    Console.Write("\n Игрок восстановил часть здоровья = " + recovery + ".\n");
                    if (healthHero > maxHealth)
                    {
                        Console.Write(" Превышение максимального здоровья игрока.");
                        healthHero = maxHealth;
                    }
                }
                else if (input == ulta)
                {
                    healthBoss = healthBoss - ultaDamage;
                    Console.Write("\n Заклинание ульта нанес серьезный урон боссу = " + ultaDamage + " .\n");
                    healthHero = healthHero - selfDamage;
                    Console.Write("\n Вы ранили самого себя, урон = " + selfDamage + " .\n Ваше хп = " + healthHero + ".\n");
                }


                if(input == huganzakura && huganzakuraOpen == false)
                {
                    Console.Write("\n Босс не атаковал.\n");
                }
                else if (input == rift)
                {
                    Console.Write("\n Босс не может попасть по вам.\n\n");
                }
                else if (input == ulta || input == rashamon || (input == huganzakura && huganzakuraOpen == true))
                {
                    healthHero = healthHero - damageBoss;
                    Console.Write(" Босс ударил по игроку, урон = " + damageBoss + ".\n\n");
                }
            }

            Console.Write("\n Игра битва с боссом завершается.\n\n");
        }
    }
}