﻿using System;

namespace Администрирование_кафе
{
    class Program
    {
        static void Main(string[] args)
        {
            Table[] tables = { new Table(1, 5), new Table(2, 10), new Table(3, 20) };
            bool isOpen = true;

            while (isOpen == true)
            {
                Console.WriteLine("\n Приложение - Администрирование кафе.\n В данном приложении можно зарезервировать места у определенного стола.\n комадны: reserv - зерезвация мест у стола.\n exit -" +
                " выход из приложения.\n");

                for (int i = 0; i < tables.Length; i++)
                {
                    tables[i].ShowInfo();
                }

                Console.Write("\n Введите комманду: ");
                string command = Console.ReadLine();

                if (command == "reserv")
                {
                    Console.Write(" Введите номер стола: ");
                    int userTable = Convert.ToInt32(Console.ReadLine()) - 1;
                    Console.Write(" Введите количество мест: ");
                    int userPlace = Convert.ToInt32(Console.ReadLine());

                    bool isReserve = tables[userTable].Reserve(userPlace);

                    if (isReserve)
                    {
                        Console.Write("\n Бронь прошла успешно.");
                    }
                    else
                    {
                        Console.Write("\n Ошибка брони.");
                    }
                }

                if (command == "exit")
                {
                    isOpen = false;
                }

                Console.Write("\n\n Нажмите любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Программа Администрирование кафе завершается.");
        }
    }

    class Table
    {
        private int _number;
        private int _maxPlace;
        private int _freePlace;

        public Table(int number, int maxPlace)
        {
            _number = number;
            _maxPlace = maxPlace;
            _freePlace = maxPlace;
        }

        public void ShowInfo()
        {
            Console.WriteLine(" Стол - " + _number + ". Свободно мест - " + _freePlace + "/" + _maxPlace + ".");
        }

        public bool Reserve(int place)
        {
            bool isReserve;

            isReserve = _freePlace >= place;
            if (isReserve)
            {
                _freePlace -= place;
                return isReserve;
            }
            else
            {
                return isReserve;
            }
        }
    }
}