﻿using System;
using System.Collections.Generic;

namespace Кадровый_учет_продвинутый
{
    class Program
    {
        static void Main(string[] args)
        {
            string command = "";
            List<string> fullName = new List<string>(0);
            List<string> post = new List<string>(0);

            while (command != "e")
            {
                Console.Write("\n Добро пожаловать в приложение - кадровый учет продвинутый.\n Имеются команды:\n a (add - добавить досье) - вводить ФИО через пробел,\n o (out - вывести все досье),\n" +
                " d (delete - удалить досье, полученное по поиску фамилии человека),\n e (exit - выход из приложения).\n");
                Console.Write("\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "a":
                        AddDossier(fullName, post);
                        break;
                    case "o":
                        ShowDossier(fullName, post);
                        break;
                    case "d":
                        DeleteDossier(fullName, post);
                        break;
                    case "e":
                        ExitАpplication();
                        break;
                }

                Console.Write(" Нажмите любую клавишу ");
                Console.ReadKey();
                Console.Clear();
            }
        }

        static void AddDossier(List<string> fullName, List<string> post)
        {
            Console.Write(" Введите ФИО человека: ");
            fullName.Add(Console.ReadLine());
            Console.Write(" Введите должность человека: ");
            post.Add(Console.ReadLine());
        }

        static void ShowDossier(List<string> fullName, List<string> post)
        {
            Console.Write("  Вывод всех досье:");
            for (int i = 0; i < fullName.Count; i++)
            {
                Console.Write("\n " + i + " ФИО - " + fullName[i] + "  Должность - " + post[i]);
            }
            Console.Write("\n");
        }

        static void DeleteDossier(List<string> fullName, List<string> post)
        {
            Console.Write(" Введите порядковый номер человека, которого вы хотите удалить: ");
            if (int.TryParse(Console.ReadLine(), out int delete))
            {
                for (int i = 0; i < fullName.Count; i++)
                {
                    if (delete > 0 && delete < fullName.Count)
                    {
                        fullName.RemoveAt(delete);
                        post.RemoveAt(delete);
                    }
                }
            }
        }

        static void ExitАpplication()
        {
            Console.Write("\n Приложение кадровый учет завершается.\n Нажмите на любую клавишу.\n");
        }
    }
}