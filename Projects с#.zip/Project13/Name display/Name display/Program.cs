﻿using System;

namespace Name_display
{
    class Program
    {
        static void Main(string[] args)
        {
            int length;
            int count;
            string name;
            string symbol;

            Console.Write(" Программа - вывод имени.\n В программе будет выведено имя пользователя с символом, который пользователь сам задаст.\n\n Введите ваше имя: ");
            name = Console.ReadLine();
            Console.Write(" Введите ваш предпочтительный символ: ");
            symbol = Console.ReadLine();
            Console.Write("\n");

            length = name.Length;
            for (count = -1; count < length + 1; count++)
            {
                if (count == -1)
                {
                    Console.Write(" ");
                }
                Console.Write(symbol);
            }
            Console.Write("\n " + symbol + name + symbol + "\n");
            for (count = -1; count < length + 1; count++)
            {
                if (count == -1)
                {
                    Console.Write(" ");
                }
                Console.Write(symbol);
            }
            Console.Write("\n\n");
        }
    }
}