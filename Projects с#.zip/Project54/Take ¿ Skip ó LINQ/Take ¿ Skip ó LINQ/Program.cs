﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Take_и_Skip_в_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            ActionsWithPlayers actionsWithPlayers = new ActionsWithPlayers();
            actionsWithPlayers.Start();
        }
    }

    class ActionsWithPlayers
    {
        public void Start()
        {
            List<Player> players = new List<Player> { new Player("ДжинОни", 100), new Player("ИзЦирка", 220), new Player("Дресслер", 250), new Player("Kekeksay", 241) };

            Console.Write(" Приложение - Выборка игроков на LINQ.\n Данная программа имеет список игроков, которых пропускают или берут по определнным условиям и затем выводится в\n консоль.\n\n");

            Console.Write("\n Список игроков коллекции:\n");
            foreach (var player in players)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            var resultSkip = players.Skip(2);

            Console.Write("\n Список игроков с пропуском первого и второго игрока из коллекции:\n");
            foreach (var player in resultSkip)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            var resultTake = players.Take(2);

            Console.Write("\n Список игроков с взятием первого и второго игрока из коллекции:\n");
            foreach (var player in resultTake)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            var resultSkipWhile = players.SkipWhile(player => player.Login.StartsWith("Д"));

            Console.Write("\n Список игроков с пропуском игрока, которое начинается с буквы Д из коллекции:\n");
            foreach (var player in resultSkipWhile)
            {
                Console.Write(" " + player.Login + ".\n");
            }

            var resultTakeWhile = players.TakeWhile(player => player.Login.StartsWith("Д"));

            Console.Write("\n Список игроков с взятием игрока, у которого имя начинается с буквы Д из коллекции:\n");
            foreach (var player in resultTakeWhile)
            {
                Console.Write(" " + player.Login + ".\n");
            }
        }
    }

    class Player
    {
        public string Login { get; private set; }
        public int Level { get; private set; }

        public Player(string login, int level)
        {
            Login = login;
            Level = level;
        }
    }
}