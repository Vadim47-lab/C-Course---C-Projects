﻿using System;

namespace UIELEMENT
{
    class Program
    {
        static void Main(string[] args)
        {
            int health = 5;
            int maxHealth = 10;
            int mana = 3;
            int maxMana = 10;
            string command = "";
            string changeValue;

            while (command != "exit")
            {
                Console.Write("\n Порграмма - Health bar. Данная программа запрашивает данные о мане и здоровье у пользователя и отрисовывает\n шкалу здоровья и ману персонажа.\n Имеются такие команды: exit - " +
                " выход из программы, change - изменение количества здоровья и маны персонажа.\n\n   Здоровье:");
                DrowBar(health, maxHealth, ConsoleColor.Red, 6, '_');
                Console.Write("\n    Мана:");
                DrowBar(mana, maxMana, ConsoleColor.Blue, 8, '_');
                Console.SetCursorPosition(0, 10);

                Console.Write(" Введите комнаду: ");
                command = Console.ReadLine();

                if (command == "change")
                {
                    Console.Write("\n Насколько Вы хотите изменить значения параметров?\n Команды: increase - увеличение значений параметров, decrease - уменьшение значений параметров\n Введите комнаду: ");
                    changeValue = Console.ReadLine();

                    if (changeValue == "increase")
                    {
                        Console.Write(" Введите число, на которое изменится жизнь персонажа: ");
                        health += Convert.ToInt32(Console.ReadLine());
                        Console.Write(" Введите число, на которое изменится мана персонажа: ");
                        mana += Convert.ToInt32(Console.ReadLine());
                    }
                    else if (changeValue == "decrease")
                    {
                        Console.Write(" Введите число, на которое изменится жизнь персонажа: ");
                        health -= Convert.ToInt32(Console.ReadLine());
                        Console.Write(" Введите число, на которое изменится мана персонажа: ");
                        mana -= Convert.ToInt32(Console.ReadLine());
                    }

                    Console.WriteLine(" Нажмите любую клавишу.");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
            Console.WriteLine("\n Программа Health bar завершается.");
        }

        static void DrowBar(int value, int maxValue, ConsoleColor color, int position, char symbol = ' ')
        {
            string bar = "";
            string marginLeft = "";
            string lattice = "#";
            int percent = 4;
            ConsoleColor defaultColor = Console.BackgroundColor;

            for (int i = 0; i < value; i++)
            {
                bar += symbol;
            }

            Console.SetCursorPosition(0, position);
            Console.Write(' ');
            Console.Write('[');

            if (value <= percent)
            {
                bar = lattice;
            }
            else
            {
                Console.BackgroundColor = color;
            }

            Console.Write(marginLeft);
            Console.Write(bar);
            Console.BackgroundColor = defaultColor;

            bar = "";

            for (int i = value; i < maxValue; i++)
            {
                bar += symbol;
            }

            Console.Write(bar + ']');
        }
    }
}