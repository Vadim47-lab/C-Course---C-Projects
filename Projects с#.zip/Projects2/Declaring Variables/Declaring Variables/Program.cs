﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Declaring_Variables
{
    class Program
    {
        static void Main(string[] args)
        {

            byte level = 10;
            sbyte type = 20;
            short age = 30;
            ushort rabbitCount = 15;
            int foxCount = 1;
            uint pictureCount = 3;
            long pointCount = 1000;
            ulong people = 100;

            float water = 1.5f;
            double sugar = 3.4f;

            char number = '1';

            string surname = "Владислав";

            bool isUser = false;
        }
    }
}
