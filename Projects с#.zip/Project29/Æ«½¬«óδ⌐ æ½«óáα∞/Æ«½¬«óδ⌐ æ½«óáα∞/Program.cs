﻿using System;
using System.Collections.Generic;

namespace Толковый_Словарь
{
    class Program
    {
        static void Main(string[] args)
        {
            string word;
            bool exit = false;
            Dictionary<string, int> countries = new Dictionary<string, int>();
            countries.Add("Россия", 0);
            countries.Add("Африка", 1);
            countries.Add("Япония", 2);
            countries.Add("Турция", 3);
            countries.Add("Испания", 4);
            countries.Add("Италия", 5);
            countries.Add("Китай", 6);

            while(exit != true)
            {
                Console.WriteLine("\n Программа - Толковый словарь.\n Данной программе нужно ввести слово - страну, чтобы получить его значение.\n");
                foreach (var value in countries)
                {
                    Console.WriteLine($" Страна - {value.Key}");
                }

                Console.Write("\n Введите слово: ");
                word = Console.ReadLine();

                if (countries.ContainsKey(word))
                {
                    Console.WriteLine($"\n Значение слова " + word + " - " + countries[word]);
                    exit = true;
                }
                else
                {
                    Console.WriteLine("\n Нет такого слова. Попробуйте еще раз.");
                }

                Console.WriteLine(" Нажмите любую клавишу");
                Console.ReadKey();
                Console.Clear();
            }
        }
    }
}