﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Определение_просрочки
{
    class Program
    {
        static void Main(string[] args)
        {
            FoodSet foodSet = new FoodSet();
            foodSet.StartWork();
        }
    }

    class FoodSet
    {
        private readonly List<Stew> _stews;

        public FoodSet()
        {
            _stews = new List<Stew>();
        }

        public void StartWork()
        {
            string command = "";

            AddStews();

            while (command != "exit")
            {
                Console.Write(" Приложение - Определение просрочки.\n В данной программе есть набор тушенки. У тушенки есть название, год производства и срок годности. Написать запрос для " +
                "получения всех просроченных банок тушенки. Чтобы не заморачиваться, будем думать, что считаем только года, без месяцев.\n\n Команды:\n 1) output - вывод всех просроченных " +
                "банок тушенки;\n 2) exit - выход из программы.\n");

                Console.Write("\n Список всех банок тушенки:\n");
                ShowStews(_stews);

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "output":
                        GettingStewExpiredCans();
                        break;
                }

                Console.Write("\n\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Определение просрочки завершается.\n");
        }

        private void AddStews()
        {
            Stew _stew1 = new Stew("тушенка со свининой", 2018, 1);
            Stew _stew2 = new Stew("говядина тушенная", 2017, 3);
            Stew _stew3 = new Stew("баранина тушенная", 2016, 2);
            Stew _stew4 = new Stew("тушенка из говядины", 2013, 4);
            Stew _stew5 = new Stew("свинина тушенная", 2021, 5);

            _stews.Add(_stew1);
            _stews.Add(_stew2);
            _stews.Add(_stew3);
            _stews.Add(_stew4);
            _stews.Add(_stew5);
        }

        private void ShowStews(List<Stew> CansStew)
        {
            for (int i = 0; i < CansStew.Count; i++)
            {
                Console.Write(" Номер - " + i);

                CansStew[i].ShowDescription();
            }
        }

        private void GettingStewExpiredCans()
        {
            int todayYear = DateTime.Today.Year;

            var resultExpiredCansStew = _stews.Where(stew => (stew.ProductionYear + stew.ShelfLife) < todayYear).ToList();

            Console.Write("\n Вывод всех просроченных банок тушенки:\n");

            ShowStews(resultExpiredCansStew);
        }
    }

    class Stew
    {
        private readonly string _title;

        public int ProductionYear { get; private set; }
        public int ShelfLife { get; private set; }

        public Stew(string title, int productionYear, int shelfLife)
        {
            _title = title;
            ProductionYear = productionYear;
            ShelfLife = shelfLife;
        }

        public void ShowDescription()
        {
            Console.Write(", название - " + _title + ", год производства - " + ProductionYear + " год, срок годности - " + ShelfLife + " год(ов).\n");
        }
    }
}