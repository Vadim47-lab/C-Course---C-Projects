﻿using System;
using System.Collections.Generic;

namespace Зоопарк
{
    class Program
    {
        static void Main(string[] args)
        {
            Zoo zoo = new Zoo();
            zoo.StartExcursion();
        }
    }

    class Zoo
    {
        private readonly List<Animal> _animal;

        public Zoo()
        {
            Tiger tiger = new Tiger("Тигр", 10, "мужской", "Рык");
            Elephant elephant = new Elephant("Слон", 5, "женский", "могущественный звук слонов");
            Bear bear = new Bear("Медведь", 6, "мужской", "Злое рычание медведя");
            Fox fox = new Fox("Лиса", 4, "женский", "звук рыжей лисицы в природе");
            Giraffe giraffe = new Giraffe("Жираф", 2, "женский", "рычание жирафа");

            _animal = new List<Animal> { tiger, elephant, bear, fox, giraffe };
        }

        public void StartExcursion()
        {
            int command = 0;

            while (command != 5)
            {
                Console.Write("\n Приложение - Зоопарк.\n В этом приложении имеется меню, в котором пользователь может выбрать, к какому вольеру подойти. При приближении к\n вольеру, ему" +
                " выводится информация о том, что это за вольер, сколько животных там обитает, их пол и какой звук издает\n животное.\n\n Команды:\n 0 - первый вольер;\n 1 - второй вольер;" +
                "\n 2 - третий вольер;\n 3 - четвертый вольер;\n 4 - пятый вольер;\n 5 - выход из приложения.\n\n");

                Console.Write(" Список вольеров:\n");
                for (int i = 0; i < _animal.Count; i++)
                {
                    Console.Write(" Номер - " + i + "\n");
                }

                Console.Write("\n\n Введите команду: ");
                if (int.TryParse(Console.ReadLine(), out command))
                {

                    switch (command)
                    {
                        case 0:
                            ApproachingAviary(command);
                            _animal[command].ShowDescription();
                            break;
                        case 1:
                            ApproachingAviary(command);
                            _animal[command].ShowDescription();
                            break;
                        case 2:
                            ApproachingAviary(command);
                            _animal[command].ShowDescription();
                            break;
                        case 3:
                            ApproachingAviary(command);
                            _animal[command].ShowDescription();
                            break;
                        case 4:
                            ApproachingAviary(command);
                            _animal[command].ShowDescription();
                            break;
                    }

                    PressAnyKey();
                }
                else
                {
                    Console.Write("\n Вы ввели не число. Повторите попытку еще раз.");
                    PressAnyKey();
                }

                Console.Write("\n Приложение Зоопарк завершается.\n");
            }
        }

        public void ApproachingAviary(int command)
        {
            Console.Write("\n Вы подошли к " + command + " вольеру.\n");
        }

        public void PressAnyKey()
        {
            Console.Write("\n Нажмите на любую клавишу.");
            Console.ReadKey();
            Console.Clear();
        }
    }

    class Animal
    {
        private readonly string _name;
        private readonly int _amount;
        private readonly string _gender;
        private readonly string _sound;

        public Animal(string name, int amount, string gender, string sound)
        {
            _name = name;
            _amount = amount;
            _gender = gender;
            _sound = sound;
        }

        public void ShowDescription()
        {
            Console.WriteLine(" Название: " + _name + ", количество животных: " + _amount + ", пол: " + _gender + ", звук животного: " + _sound + ".");
        }
    }

    class Tiger : Animal
    {
        public Tiger(string name, int amount, string gender, string sound) : base(name, amount, gender, sound) { }
    }

    class Elephant : Animal
    {
        public Elephant(string name, int amount, string gender, string sound) : base(name, amount, gender, sound) { }
    }

    class Bear : Animal
    {
        public Bear(string name, int amount, string gender, string sound) : base(name, amount, gender, sound) { }
    }

    class Fox : Animal
    {
        public Fox(string name, int amount, string gender, string sound) : base(name, amount, gender, sound) { }
    }

    class Giraffe : Animal
    {
        public Giraffe(string name, int amount, string gender, string sound) : base(name, amount, gender, sound) { }
    }
}