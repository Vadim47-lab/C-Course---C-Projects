﻿using System;
using System.Collections.Generic;

namespace Аквариум
{
    class Program
    {
        static void Main(string[] args)
        {
            Aquarium aquarium = new Aquarium();
            aquarium.StartLife();
        }
    }

    class Aquarium
    {
        private readonly List<Fish> _fishes;
        private readonly int _maxAquariumCapacity = 5;

        public int AquariumCapacity => _fishes.Count;

        public Aquarium()
        {
            Catfish catfish = new Catfish("Cом", 30, 6);
            Crucian crucian = new Crucian("Карась", 20, 50);

            _fishes = new List<Fish> { catfish, crucian };
        }

        public void StartLife()
        {
            string command = "";

            while (command != "exit")
            {
                Console.Write("\n Приложение - Аквариум.\n В этом приложении имется определенный максимум количества рыб, у рыб также есть возраст. За 1 итерацию рыбы стареют на  определенное количество жизней" +
                " и могут умереть. Рыб можно добавить в аквариум, и рыб можно достать из аквариума.\n\n Команды:\n add - добавить рыб в аквариум;\n get - достать рыбу;\n exit - выход из приложения.\n\n");

                ShowMaxCapacity();
                ShowDescription();

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "add":
                        AddFish();
                        break;
                    case "get":
                        GetFish();
                        break;
                }

                AgingFish();

                DeathFish();

                Console.Write("\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Аквариум завершается.\n");
        }

        public void ShowDescription()
        {
            Console.Write(" Список рыб:\n");
            for (int i = 0; i < _fishes.Count; i++)
            {
                Console.Write(" Номер " + i + ", ");
                _fishes[i].ShowDescription();
            }
        }

        public void ShowMaxCapacity()
        {
            Console.Write("\n Максимальное количество рыб = " + _maxAquariumCapacity + ".\n\n");
        }

        public void AddFish()
        {
            string name;

            if (AquariumCapacity == _maxAquariumCapacity)
            {
                Console.Write(" Достигнуто максимальное количество рыб = " + _maxAquariumCapacity + ".\n");
                return;
            }
            else if (AquariumCapacity != _maxAquariumCapacity)
            {
                Console.Write("\n Введите название рыбы: ");
                name = Console.ReadLine();

                RequestInputLife(name);
            }
        }

        public void RequestInputLife(string name)
        {
            Console.Write(" Введите количество жизней рыбы: ");
            if (int.TryParse(Console.ReadLine(), out int life))
            {
                RequestInputWeight(name, life);
            }
            else
            {
                Console.Write(" Вы ввели не возраст рыбы. Пожалуйста повторите попытку еще раз.\n\n");
                RequestInputLife(name);
            }
        }

        public void RequestInputWeight(string name, int life)
        {
            Console.Write(" Введите вес рыбы: ");
            if (int.TryParse(Console.ReadLine(), out int weight))
            {
                Fish fish = new Fish(name, life, weight);
                _fishes.Add(fish);
                Console.Write("\n Рыба добавлена в аквариум.");
            }
            else
            {
                Console.Write(" Вы ввели не вес рыбы. Пожалуйста повторите попытку еще раз.\n\n");
                RequestInputWeight(name, life);
            }
        }

        public void GetFish()
        {
            int minNumber = 0;

            Console.Write("\n Введите номер рыбы, которую вы хотите забрать из аквариума: ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                if (number < minNumber)
                {
                    Console.Write("\n Вы ввели число выходящее за диапазон списка рыб. Пожалуйста повторите попытку еще раз.");
                }
                else if (number > _maxAquariumCapacity)
                {
                    Console.Write("\n Вы ввели число выходящее за диапазон списка рыб. Пожалуйста повторите попытку еще раз.");
                }
                else
                {
                    _fishes.RemoveAt(number);
                    Console.Write("\n Выбранная вами рыба взята из аквариума.");
                }
            }
            else
            {
                Console.Write(" Вы ввели не номер рыбы. Пожалуйста повторите попытку еще раз.");
            }
        }

        public void AgingFish()
        {
            for (int i = 0; i < _fishes.Count; i++)
            {
                _fishes[i].Life--;
            }
        }

        public void DeathFish()
        {
            for (int i = 0; i < _fishes.Count; i++)
            {
                if (_fishes[i].Life <= 0)
                {
                    _fishes.RemoveAt(i);
                }
            }
        }
    }

    class Fish
    {
        public string Name { get; set; }
        public int Weight { get; set; }
        public int Life { get; set; }

        public Fish(string name, int life, int weight)
        {
            Name = name;
            Weight = weight;
            Life = life;
        }

        public void ShowDescription()
        {
            Console.WriteLine("Название: " + Name + ", жизнь: " + Life + ", вес: " + Weight + " кг.");
        }
    }

    class Catfish : Fish
    {
        public Catfish(string name, int weight, int age) : base(name, weight, age) { }
    }

    class Crucian : Fish
    {
        public Crucian(string name, int weight, int age) : base(name, weight, age) { }
    }
}