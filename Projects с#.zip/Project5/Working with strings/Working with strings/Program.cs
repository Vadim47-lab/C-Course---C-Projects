﻿using System;

namespace Working_with_strings
{
    class Program
    {
        static void Main(string[] args)
        {
            string Name;
            string age;
            string zodiacSign;
            string profession;
            string hobi;
            string entertainment;

            Console.Write("Введите ваше имя: ");
            Name = Console.ReadLine();
            Console.Write("Введите ваш возраст: ");
            age = Console.ReadLine();
            Console.Write("Введите ваш знак зодиака: ");
            zodiacSign = Console.ReadLine();
            Console.Write("Введите ваше хоби: ");
            hobi = Console.ReadLine();
            Console.Write("Введите ваше развлечение: ");
            entertainment = Console.ReadLine();
            Console.Write("Введите вашу профессию: ");
            profession = Console.ReadLine();

            Console.Write("\nВас зовут " + Name + ", вам " + age + " год, вы " + zodiacSign + ", ваше хоби " + hobi + ", ваше развлечение " + entertainment + " и ваша профессия " +
            profession + ".\n");
        }
    }
}
