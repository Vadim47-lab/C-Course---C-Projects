﻿using System;

namespace mastering_cycles
{
    class Program
    {
        static void Main(string[] args)
        {
            int output;
            int messagedisplayСounter;

            Console.Write(" Программа - oсвоение циклов.\n Введите число, которое будет выводить сообщение заданное вами количество раз: ");
            output = Convert.ToInt32(Console.ReadLine());
            Console.Write("\n");
            for (messagedisplayСounter = 0; messagedisplayСounter < output; messagedisplayСounter++)
            {
                Console.Write(" Привет Друг! Как дела? Какие планы у тебя сегодня?\n");
            }
        }
    }
}