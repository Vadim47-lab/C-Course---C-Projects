﻿using System;

namespace working_with_specific_rows__columns
{
    class Program
    {
        static void Main(string[] args)
        {
            int line;
            int column;
            int sum = 0;
            int multiplication = 1;
            int[,] matrix = { {1, 4, 2},
                              {5, 6, 7}, 
                              {8, 9, 3} };

            column = 1;
            for (line = 0; line < matrix.GetLength(0); line++)
            {
                sum += matrix[column, line];
            }

            line = 0;
            for (column = 0; column < matrix.GetLength(1); column++)
            {
                multiplication *= matrix[column, line];
            }

            Console.WriteLine(" Исходная матрица");
            for (line = 0; line < matrix.GetLength(0); line++)
            {
                Console.Write(" ");
                for (column = 0; column < matrix.GetLength(1); column++)
                {
                    Console.Write(matrix[line, column] + " ");
                }
                Console.WriteLine();
            }

            Console.WriteLine("\n Сумма 2 строки матрицы = " + sum);
            Console.WriteLine(" Произведение 1 столбца = " + multiplication);
            Console.WriteLine("\n\n Программа работа с конкретными строками/столбцами заврешается.");
        }
    }
}