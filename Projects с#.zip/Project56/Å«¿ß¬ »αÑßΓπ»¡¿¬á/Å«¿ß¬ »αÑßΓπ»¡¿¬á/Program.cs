﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Поиск_преступника
{
    class Program
    {
        static void Main(string[] args)
        {
            Detective detective = new Detective();
            detective.BeginningWork();
        }
    }

    class Detective
    {
        private readonly List<Criminal> _criminals;

        public Detective()
        {
            _criminals = new List<Criminal>();
        }

        public void BeginningWork()
        {
            string command = "";

            AddCriminals();

            while (command != "exit")
            {
                Console.Write(" Приложение - Поиск преступника.\n Данная программа имеет список всех преступников. У преступника есть: ФИО, заключен ли он под стражу, рост, вес,\n национальность" +
            ". Данной программой пользуются детективы. У детектива запрашиваются данные (рост, вес, национальность),\n и детективу выводятся все преступники, которые подходят под эти параметры" +
            ", но уже заключенные под стражу выводиться не  должны.\n\n Команды:\n show - показ списка преступников;\n search - поиск преступников;\n exit - выход из программы.\n");

                Console.Write("\n\n Введите команду: ");
                command = Console.ReadLine();

                switch (command)
                {
                    case "show":
                        ShowCriminals();
                        break;
                    case "search":
                        InputHeight();
                        break;
                }

                Console.Write("\n\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение Поиск преступника завершается.\n");
        }

        public void AddCriminals()
        {
            Criminal criminal1 = new Criminal("Петров Петр Петрович", false, 120, 80, "Русская");
            Criminal criminal2 = new Criminal("Иван Иванов Иванович", true, 160, 85, "Японская");
            Criminal criminal3 = new Criminal("Сидоров Сидр Сидорович", false, 180, 90, "Корейская");
            Criminal criminal4 = new Criminal("Александров Александр Александрович", true, 100, 95, "Турецкая");

            _criminals.Add(criminal1);
            _criminals.Add(criminal2);
            _criminals.Add(criminal3);
            _criminals.Add(criminal4);
        }

        public void ShowCriminals()
        {
            Console.Write("\n Список преступников:");
            for (int i = 0; i < _criminals.Count; i++)
            {
                Console.Write("\n Номер - " + i);
                _criminals[i].ShowDescription();
            }
        }

        public void InputHeight()
        {
            Console.Write("\n Введите возраст: ");
            if (int.TryParse(Console.ReadLine(), out int height))
            {
                InputWeight(height);
            }
            else
            {
                Console.Write("\n Вы ввели не рост. Повторите попытку еще раз.");
                InputHeight();
            }
        }

        public void InputWeight(int height)
        {
            Console.Write(" Введите вес: ");
            if (int.TryParse(Console.ReadLine(), out int weight))
            {
                InputNationality(height, weight);
            }
            else
            {
                Console.Write("\n Вы ввели не вес. Повторите попытку еще раз.");
                InputWeight(height);
            }
        }

        public void InputNationality(int height, int weight)
        {
            string nationality;

            Console.Write(" Введите национальность: ");
            nationality = Console.ReadLine();

            SearchCriminal(height, weight, nationality);
        }

        public void SearchCriminal(int height, int weight, string nationality)
        {
            var resultSearch = _criminals.Where(criminal => criminal.Height == height && criminal.Weight == weight && criminal.Nationality == nationality && criminal.IsUnderArest == false)
            .ToList();

            for (int i = 0; i < resultSearch.Count; i++)
            {
                Console.Write("\n\n Список преступников подходящих под данные параметры:\n Номер - " + i);
                resultSearch[i].ShowDescription();
            }
        }
    }

    class Criminal
    {
        private readonly string _fullName;

        public int Height { get; private set; }
        public int Weight { get; private set; }
        public string Nationality { get; private set; }
        public bool IsUnderArest { get; private set; }

        public Criminal(string fullname, bool isUnderArest, int height, int weight, string nationality)
        {
            _fullName = fullname;
            IsUnderArest = isUnderArest;
            Height = height;
            Weight = weight;
            Nationality = nationality;
        }

        public void ShowDescription()
        {
            Console.Write(", ФИО - " + _fullName + ", заключение под стражу - " + IsUnderArest + ", рост - " + Height + ", вес - " + Weight + ",\n национальность - " + Nationality + ".\n");
        }
    }
}