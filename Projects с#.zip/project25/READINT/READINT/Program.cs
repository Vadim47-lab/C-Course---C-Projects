﻿using System;

namespace READINT
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            string value = "";

            Console.Write("\n Программа - конвертация числа.\n");

            while(exit != true)
            {
                ConversionNumber (ref value, ref exit);
                if (exit == true) Console.Write("\n Возвращаемое число = " + value + "\n Нажмите на любую клавишу\n");
            }
        }

        static void ConversionNumber(ref string value, ref bool exit)
        {
            Console.Write(" Введите число: ");
            value = Console.ReadLine();

            int number;
            bool success = Int32.TryParse(value, out number);

            if (success)
            {
                Console.WriteLine(" Преобразовано число '{0}' ", value, number);
                exit = true;
                return;
            }
            else
            {
                Console.WriteLine(" Попытка преобразования '{0}' не удалась.\n",
                               value ?? "<null>");
            }
        }
    }
}