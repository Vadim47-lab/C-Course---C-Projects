﻿using System;

namespace Battle
{
    class Program
    {
        static void Main(string[] args)
        {
            Fighter[] fighters = { new Fighter("John", 500, 50, 0), new Fighter("Mark", 250, 20, 25), new Fighter("Alex", 150, 100, 10), new Fighter("Max", 300, 30, 0)};
            int fighterIndex;
            string command = "";

            while(command != "exit")
            {
                Console.Write("\n Приложение - Битва.\n В этом приложении пользователю нужно будет выбрать бойцов для битвы и будет выведен результат их битвы.\n Команды: fight - запуск битвы бойцов," +
                " exit - выход из приложения.\n Пояснение параметров: HP - жизнь, DMG - урон, Armor - броня.\n\n");
                for (int i = 0; i < fighters.Length; i++)
                {
                    Console.Write(" " + i + " ");
                    fighters[i].ShowStats();
                }

                Console.Write("\n Введите команду: ");
                command = Console.ReadLine();

                if (command == "fight")
                {
                    Console.Write("\n Введите бойца правой стороны: ");
                    fighterIndex = Convert.ToInt32(Console.ReadLine());
                    Fighter rightFigther = fighters[fighterIndex];

                    Console.Write(" Введите бойца левой стороны: ");
                    fighterIndex = Convert.ToInt32(Console.ReadLine());
                    Fighter leftFigther = fighters[fighterIndex];

                    while (leftFigther.Health > 0 && rightFigther.Health > 0)
                    {
                        Console.WriteLine();
                        leftFigther.TakeDamage(rightFigther.Damage);
                        rightFigther.TakeDamage(leftFigther.Damage);
                        leftFigther.ShowStats();
                        rightFigther.ShowStats();
                    }

                    if (rightFigther.Health < 0)
                    {
                        Console.Write("\n Победил ");
                        leftFigther.Winner();
                    }
                    else if (leftFigther.Health < 0)
                    {
                        Console.Write("\n Победил ");
                        rightFigther.Winner();
                    }
                    else if (rightFigther.Health < 0 && leftFigther.Health < 0)
                    {
                        Console.Write("\n Оба бойца побигли.");
                    }
                }

                Console.Write("\n Нажмите на любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Приложение битвы завершается.\n");
        }
    }

    class Fighter
    {
        private readonly string _name;
        private int _health;
        private readonly int _damage;
        private readonly int _armor;

        public int Health
        {
            get
            {
                return _health;
            }
        }
        public int Damage
        {
            get
            {
                return _damage;
            }
        }


        public Fighter(string name, int health, int damage, int armor)
        {
            _name = name;
            _health = health;
            _damage = damage;
            _armor = armor;
        }

        public void ShowStats()
        {
            Console.WriteLine(_name + ", HP: " + _health + ", DMG: " + _damage + ", Armor: " + _armor + ".");
        }

        public void Winner()
        {
            Console.WriteLine(_name);
        }

        public void TakeDamage(int damage)
        {
            _health -= damage - _armor;
        }
    }
}