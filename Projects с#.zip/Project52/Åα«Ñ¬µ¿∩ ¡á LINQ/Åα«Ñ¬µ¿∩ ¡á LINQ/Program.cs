﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Проекция_на_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            ActionsWithPlayers actionsWithPlayers = new ActionsWithPlayers();
            actionsWithPlayers.Start();
        }
    }

    class ActionsWithPlayers
    {
        public void Start()
        {
            List<Player> players = new List<Player> { new Player("ДжинОни", 100), new Player("ИзЦирка", 220), new Player("Дресслер", 250), new Player("Kekeksay", 241) };

            Console.Write(" Приложение - Выборка игроков на LINQ.\n Данная программа имеет список игроков, потом делаем запрос проекции по имени и дню рождения и затем выводятся в\n консоль." +
            "\n\n");

            var newPlayer = from Player player in players
                            select new
                            {
                                Name = player.Login,
                                DateOfBirth = "сегодня"
                            };

            Console.Write("\n Список игроков по имени c помощью проекции:\n");
            foreach (var player in newPlayer)
            {
                Console.Write(" " + player.Name + ".\n");
            }

            Console.Write("\n Список игроков по дате рождения c помощью проекции:\n");
            foreach (var player in newPlayer)
            {
                Console.Write(" " + player.DateOfBirth + ".\n");
            }

            var newPlayers = players.Select(player => new
                            {
                                Name = player.Login,
                                DateOfBirth = "сегодня"
                            });

            Console.Write("\n Список игроков по имени c помощью расширения:\n");
            foreach (var player in newPlayers)
            {
                Console.Write(" " + player.Name + ".\n");
            }

            Console.Write("\n Список игроков по дате рождения c помощью расширения:\n");
            foreach (var player in newPlayers)
            {
                Console.Write(" " + player.DateOfBirth + ".\n");
            }
        }
    }

    class Player
    {
        public string Login { get; private set; }
        public int Level { get; private set; }

        public Player(string login, int level)
        {
            Login = login;
            Level = level;
        }
    }
}