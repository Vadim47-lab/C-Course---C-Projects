﻿using System;

namespace Gladiator_fight_game
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            float health1 = rand.Next(90, 100);
            int damage1 = rand.Next(5, 20);
            int armor1 = rand.Next(25, 65);
            float health2 = rand.Next(80, 150);
            int damage2 = rand.Next(20, 40);
            int armor2 = rand.Next(65, 100);

            Console.WriteLine(" Добро пожаловать в игру Гладиаторский бой. В игре будет представлена статистика боя 2 гладиаторов." +
            "\n Пояснение сокращений: хп (здоровье), Max Damage (максимальный урон), armor (защита).\n");
            Console.WriteLine("Гладиатор1 - " + health1 + " хп, " + damage1 + " Max Damage, " + armor1 + " armor.");
            Console.WriteLine("Гладиатор2 - " + health2 + " хп, " + damage2 + " Max Damage, " + armor2 + " armor.");
            while (health1 > 0 && health2 > 0)
            {
                health1 -= Convert.ToSingle(rand.Next(0, damage2)) / 100 * armor1;
                health2 -= Convert.ToSingle(rand.Next(0, damage1)) / 100 * armor2;
                Console.WriteLine("Гладиатор1 - " + health1 + " хп.");
                Console.WriteLine("Гладиатор2 - " + health2 + " хп.");
            }

            if (health1 <= 0 && health1 <= 0)
            {
                Console.WriteLine("Ничья, оба мертвы.");
            }
            else if (health1 <= 0)
            {
                Console.WriteLine("Гладиатор 1 пал.");
            }
            else if (health2 <= 0)
            {
                Console.WriteLine("Гладиатор 2 пал.");
            }
        }
    }
}