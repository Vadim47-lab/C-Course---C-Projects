﻿using System;
using System.Collections.Generic;

namespace Магазин
{
    class Programm
    {
        static void Main(string[] args)//Точка входа в программу Магазин
        {
            Shop shop = new Shop();
            shop.Start();
        }
    }

    class Shop//Класс Магазин который содержит игрока, продавца.
    {
        readonly private Player _player;
        readonly private Salesman _salesman;

        public Shop()
        {
            _salesman = new Salesman();
            _player = new Player();
        }

        public void Start()//Стартовый метод, в котором выводится инофрмация о количестве монет, добавляется информация об продуктах, а также есть такие возомжности, как: просмотр вещей продовца, покупка продукта 
                           //у продавца, просмотр купленных вещей и выход из программы. 
        {
            string command = "";

            _salesman.AddInfo();
            _player.Money();

            while (command != "exit")
            {
                Console.Write("\n Программа - Магазин.\n В данной программе есть продавец, он имеет у себя список товаров, и при нужде, может вам его показать, также продавец\n может продать вам" +
                 " товар. После продажи товар переходит к вам, и вы можете также посмотреть свои вещи.\n\n Команды:\n show - продавец показывает пользователю товары,\n sale - продавец продает товар" +
                 " пользователю,\n things - просмотр вещей пользователя,\n exit - выход из программы.\n");

                _player.ShowMoney();

                Console.Write("\n Введите команду: ");
                command = Console.ReadLine();
                switch (command)
                {
                    case "show":
                        _salesman.ShowInfoSalesman();
                        break;
                    case "sale":
                        _player.Sale(_salesman);
                        break;
                    case "things":
                        _player.ViewingThings();
                        break;
                }

                Console.Write("\n\n Нажмите любую клавишу.");
                Console.ReadKey();
                Console.Clear();
            }

            Console.Write("\n Программа Магазин завершается.\n");
        }
    }

    class Player//Класс, который содержит информацию о своих вещях
    {
        private int _sale;
        private int _money;
        readonly private List<Product> _things;

        public Player()
        {
            _things = new List<Product>();
        }

        public void Money()//Метод добавление денег в карман клиента
        {
            _money = 450;
        }

        public void ShowMoney()//Метод показа денег клиента
        {
            Console.Write("\n Деньги пользователя = " + _money + ".");
        }

        public void ViewingThings()//Метод показа вещей клиента
        {
            for (int i = 0; i < _things.Count; i++)
            {
                Console.Write("\n Номер продукта - " + i);
                _things[i].ShowInfo();
            }
        }

        public void Sale(Salesman _salesman)//Метод покупки товара у продавца
        {
            Console.Write("\n Введите номер продукта, который вы хотите купить: ");
            if (int.TryParse(Console.ReadLine(), out _sale))
            {
                _salesman.Sale(_sale, ref _money, _things);
            }
            else
            {
                Console.WriteLine(" Вы ввели не число. Попробуйте еще раз.");
            }
        }
    }

    class Salesman//Класс, который содержит информацию о товарах и их количества у продавца
    {
        readonly private List<Product> _products;

        public Salesman()
        {
            _products = new List<Product>();
        }

        public void AddInfo()//Метод добавления информации о продуктах
        {
            Product _product1 = new Product("Масло", "Проспект мира 14", "Россия", "Томск", 200, "10.12.21 г.", 100);
            Product _product2 = new Product("Молоко", "Проспект мира 20", "Россия", "Красноярск", 100, "11.11.21 г.", 150);
            Product _product3 = new Product("Творог", "Проспект мира 30", "Россия", "Москва", 300, "05.06.21 г.", 200);

            _products.Add(_product1);
            _products.Add(_product2);
            _products.Add(_product3);
        }

        public void ShowInfoSalesman()//Метод показа информации о продуктах продавца
        {
            for (int i = 0; i < _products.Count; i++)
            {
                Console.Write("\n Номер продукта - " + i);
                _products[i].ShowInfo();
            }
        }

        public void Sale(int _sale, ref int _money, List<Product> _things)//Метод продажи товара у продаца
        {
            if (_sale < _products.Count)
            {
                _money -= _products[_sale].Price;
                _things.Add(_products[_sale]);

                _products.RemoveAt(_sale);
                Console.WriteLine("\n Продукт куплен");
            }
            else
            {
                Console.WriteLine(" Такого продукта нет. Попробуйте еще раз.");
            }
        }
    }

    class Product//Класс, который сожержит такую информацию о продукте: наименовании продукта, местонахождения (адрес) изготовителя, названии страны, месте происхождения, массы, срок годности и цене. 
    {
        private readonly string _name;
        private readonly string _location;
        private readonly string _nameСountry;
        private readonly string _placeOrigin;
        private readonly int _weight;
        private readonly string _shelfLife;

        public int Price { get; private set; }

        public Product(string name, string location, string nameСountry, string placeOrigin, int weight, string shelfLife, int price)
        {
            _name = name;
            _location = location;
            _nameСountry = nameСountry;
            _placeOrigin = placeOrigin;
            _weight = weight;
            _shelfLife = shelfLife;
            Price = price;
        }

        public void ShowInfo()//Метод показа информации о продукте
        {
            Console.WriteLine(", наименование продукта - " + _name + ", местонахождение (адрес) изготовителя - " + _location + ",\n название страны - " + _nameСountry + ", место происхождения - " +
            _placeOrigin + ", масса - " + _weight + " гр., срок годности " + _shelfLife + ", Цена - " + Price + ".");
        }
    }
}